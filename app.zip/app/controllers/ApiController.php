<?php
/**
 * ReserBot - Controlador de API
 */

require_once __DIR__ . '/BaseController.php';

class ApiController extends BaseController {
    
    /**
     * Obtener disponibilidad de horarios
     */
    public function availability() {
        $especialista_id = $this->get('especialista_id');
        $servicio_id = $this->get('servicio_id');
        $fecha = $this->get('fecha');
        $sucursal_id = $this->get('sucursal_id');
        $excluir_reservacion = $this->get('excluir_reservacion');
        
        if (!$especialista_id || !$servicio_id || !$fecha) {
            $this->json([
                'slots' => [],
                'reason' => 'missing_parameters',
                'message' => 'Selecciona sucursal, profesionista, servicio y fecha para consultar horarios.'
            ], 400);
        }

        $dateObject = DateTime::createFromFormat('!Y-m-d', $fecha);
        if (!$dateObject || $dateObject->format('Y-m-d') !== $fecha) {
            $this->json([
                'slots' => [],
                'reason' => 'invalid_date',
                'message' => 'La fecha seleccionada no es válida.'
            ], 400);
        }

        if ($fecha < date('Y-m-d')) {
            $this->json([
                'slots' => [],
                'reason' => 'past_date',
                'message' => 'No se pueden reservar horarios en una fecha pasada.'
            ]);
        }
        
        // Verificar si el servicio es de emergencia y obtener duración personalizada
        $serviceSql =
            "SELECT es.es_emergencia, es.duracion_personalizada, s.duracion_minutos, s.nombre 
             FROM especialistas_servicios es 
             JOIN servicios s ON es.servicio_id = s.id
             JOIN especialistas e ON e.id = es.especialista_id
             JOIN usuarios u ON u.id = e.usuario_id
             JOIN sucursales suc ON suc.id = e.sucursal_id
             WHERE es.especialista_id = ? AND es.servicio_id = ?
               AND es.activo = 1 AND s.activo = 1 AND e.activo = 1
               AND e.autorizado = 1 AND u.activo = 1
               AND suc.activo = 1 AND suc.autorizado = 1";
        $serviceParams = [$especialista_id, $servicio_id];

        if ($sucursal_id) {
            $serviceSql .= " AND e.sucursal_id = ?";
            $serviceParams[] = $sucursal_id;
        }

        $servicioEspecialista = $this->db->fetch($serviceSql, $serviceParams);
        
        if (!$servicioEspecialista) {
            $this->json([
                'slots' => [],
                'reason' => 'service_not_assigned',
                'message' => 'Este servicio no está activo para el profesionista en la sucursal seleccionada.'
            ], 404);
        }
        
        $esServicioEmergencia = $servicioEspecialista['es_emergencia'];
        
        // Usar duración personalizada si existe, de lo contrario usar la duración base del servicio
        $duracion = (int) ($servicioEspecialista['duracion_personalizada'] ?? $servicioEspecialista['duracion_minutos']);
        if ($duracion <= 0) {
            $this->json([
                'slots' => [],
                'reason' => 'invalid_duration',
                'message' => 'El servicio no tiene una duración válida. Revísala en Mis Servicios.'
            ], 422);
        }
        
        // DEBUG: Log para verificar el tipo de servicio y duración
        error_log("[AVAILABILITY DEBUG] Especialista: $especialista_id, Servicio: $servicio_id, es_emergencia: " . ($esServicioEmergencia ? '1' : '0'));
        error_log("[AVAILABILITY DEBUG] Servicio: " . $servicioEspecialista['nombre'] . " - Duración personalizada: " . 
                  ($servicioEspecialista['duracion_personalizada'] ?? 'NULL') . " - Duración base: " . 
                  $servicioEspecialista['duracion_minutos'] . " - Duración final: " . $duracion . " minutos");
        
        // Obtener día de la semana
        $dayOfWeek = date('N', strtotime($fecha));
        
        // Obtener horario del especialista para la sucursal específica
        // Nota: El especialista_id que recibimos ya es específico de la sucursal
        // porque cada registro en 'especialistas' combina usuario_id + sucursal_id
        $query = "SELECT he.* FROM horarios_especialistas he
                  JOIN especialistas e ON he.especialista_id = e.id
                  WHERE he.especialista_id = ? AND he.dia_semana = ? AND he.activo = 1";
        $params = [$especialista_id, $dayOfWeek];
        
        // Si se proporciona sucursal_id adicional, verificar que coincida
        if ($sucursal_id) {
            $query .= " AND e.sucursal_id = ?";
            $params[] = $sucursal_id;
        }

        $query .= " ORDER BY he.hora_inicio ASC LIMIT 1";
        
        $schedule = $this->db->fetch($query, $params);
        
        if (!$schedule) {
            $this->json([
                'slots' => [],
                'reason' => 'no_schedule',
                'message' => 'El profesionista no tiene un horario activo para este día en la sucursal seleccionada.'
            ]);
        }
        
        // Validar bloqueos por intervalo; uno puntual no debe cancelar todo el día.
        $dayStart = $fecha . ' 00:00:00';
        $dayEnd = date('Y-m-d H:i:s', strtotime($fecha . ' +1 day'));
        $queryBlocks = "SELECT fecha_inicio, fecha_fin
                        FROM bloqueos_horario
                        WHERE especialista_id = ?
                          AND fecha_inicio < ?
                          AND fecha_fin > ?";
        $paramsBlocks = [$especialista_id, $dayEnd, $dayStart];

        if ($sucursal_id) {
            $queryBlocks .= " AND (sucursal_id = ? OR sucursal_id IS NULL)";
            $paramsBlocks[] = $sucursal_id;
        }

        $existingBlocks = $this->db->fetchAll($queryBlocks, $paramsBlocks);
        
        // Verificar feriado
        if (isHoliday($fecha, $sucursal_id ?: null)) {
            $this->json([
                'slots' => [],
                'reason' => 'holiday',
                'message' => 'La sucursal no ofrece citas en esta fecha porque está marcada como día feriado.'
            ]);
        }
        
        // Obtener citas existentes del especialista en la sucursal específica
        $queryAppointments = "SELECT hora_inicio, hora_fin FROM reservaciones 
             WHERE especialista_id = ? AND fecha_cita = ? AND estado NOT IN ('cancelada')";
        $paramsAppointments = [$especialista_id, $fecha];
        
        // Excluir la reservación que estamos reagendando
        if ($excluir_reservacion) {
            $queryAppointments .= " AND id != ?";
            $paramsAppointments[] = $excluir_reservacion;
        }
        
        // Filtrar por sucursal si se proporciona
        if ($sucursal_id) {
            $queryAppointments .= " AND sucursal_id = ?";
            $paramsAppointments[] = $sucursal_id;
        }
        
        $existingAppointments = $this->db->fetchAll($queryAppointments, $paramsAppointments);
        
        // Función auxiliar para verificar si un slot está disponible
        $isSlotAvailable = function($slotStart, $slotEnd) use ($existingAppointments, $existingBlocks, $fecha) {
            // Verificar si está en el pasado
            if ($fecha == date('Y-m-d') && $slotStart < time()) {
                return false;
            }
            
            // Verificar conflictos con citas existentes
            foreach ($existingAppointments as $appt) {
                $apptStart = strtotime($fecha . ' ' . $appt['hora_inicio']);
                $apptEnd = strtotime($fecha . ' ' . $appt['hora_fin']);
                
                if (($slotStart >= $apptStart && $slotStart < $apptEnd) ||
                    ($slotEnd > $apptStart && $slotEnd <= $apptEnd) ||
                    ($slotStart <= $apptStart && $slotEnd >= $apptEnd)) {
                    return false;
                }
            }

            foreach ($existingBlocks as $block) {
                $blockStart = strtotime($block['fecha_inicio']);
                $blockEnd = strtotime($block['fecha_fin']);

                if ($slotStart < $blockEnd && $slotEnd > $blockStart) {
                    return false;
                }
            }
            
            return true;
        };
        
        // Generar slots disponibles
        $slots = [];
        
        // Determinar qué tipo de slots generar según el tipo de servicio
        $generarSlotsNormales = !$esServicioEmergencia; // Servicios normales usan horario normal
        $generarSlotsEmergencia = $esServicioEmergencia; // Servicios de emergencia usan horario de emergencia
        
        // DEBUG: Log para verificar qué tipo de slots se generarán
        error_log("[AVAILABILITY DEBUG] Horario - Normal: " . ($schedule['hora_inicio'] ?? 'N/A') . "-" . ($schedule['hora_fin'] ?? 'N/A') . 
                  ", Emergencia: " . ($schedule['hora_inicio_emergencia'] ?? 'N/A') . "-" . ($schedule['hora_fin_emergencia'] ?? 'N/A') . 
                  ", Emergencia Activa: " . ($schedule['emergencia_activa'] ? 'SI' : 'NO'));
        error_log("[AVAILABILITY DEBUG] Generar Normales: " . ($generarSlotsNormales ? 'SI' : 'NO') . 
                  ", Generar Emergencia: " . ($generarSlotsEmergencia ? 'SI' : 'NO'));
        error_log("[AVAILABILITY DEBUG] Bloqueo Activo: " . ($schedule['bloqueo_activo'] ? 'SI' : 'NO') . 
                  ", Bloqueo: " . ($schedule['hora_inicio_bloqueo'] ?? 'N/A') . "-" . ($schedule['hora_fin_bloqueo'] ?? 'N/A'));
        error_log("[AVAILABILITY DEBUG] Citas existentes: " . count($existingAppointments));
        error_log("[AVAILABILITY DEBUG] Bloqueos aplicables: " . count($existingBlocks));
        foreach ($existingAppointments as $idx => $appt) {
            error_log("[AVAILABILITY DEBUG] Cita $idx: " . $appt['hora_inicio'] . " - " . $appt['hora_fin']);
        }
        
        // 1. Slots del horario normal (excluyendo horario de bloqueo)
        if ($generarSlotsNormales) {
            $currentTime = strtotime($fecha . ' ' . $schedule['hora_inicio']);
            $endTime = strtotime($fecha . ' ' . $schedule['hora_fin']);
            
            error_log("[AVAILABILITY DEBUG] Generando slots normales - Inicio: " . date('Y-m-d H:i:s', $currentTime) . " - Fin: " . date('Y-m-d H:i:s', $endTime) . " - Duración: $duracion min");
        
        // Si hay bloqueo activo, necesitamos dividir en dos rangos
        if ($schedule['bloqueo_activo'] && $schedule['hora_inicio_bloqueo'] && $schedule['hora_fin_bloqueo']) {
            $blockStart = strtotime($fecha . ' ' . $schedule['hora_inicio_bloqueo']);
            $blockEnd = strtotime($fecha . ' ' . $schedule['hora_fin_bloqueo']);
            
            // Rango 1: Desde inicio hasta inicio de bloqueo
            while ($currentTime + ($duracion * 60) <= $blockStart) {
                $slotStart = $currentTime;
                $slotEnd = $currentTime + ($duracion * 60);
                
                if ($isSlotAvailable($slotStart, $slotEnd)) {
                    $slots[] = [
                        'hora_inicio' => date('H:i:s', $slotStart),
                        'hora_fin' => date('H:i:s', $slotEnd),
                        'display' => formatTime(date('H:i:s', $slotStart)) . ' - ' . formatTime(date('H:i:s', $slotEnd)),
                        'tipo' => 'normal'
                    ];
                }
                
                $currentTime += 15 * 60; // Intervalo de 15 minutos
            }
            
            // Rango 2: Desde fin de bloqueo hasta fin del horario
            $currentTime = $blockEnd;
            while ($currentTime + ($duracion * 60) <= $endTime) {
                $slotStart = $currentTime;
                $slotEnd = $currentTime + ($duracion * 60);
                
                if ($isSlotAvailable($slotStart, $slotEnd)) {
                    $slots[] = [
                        'hora_inicio' => date('H:i:s', $slotStart),
                        'hora_fin' => date('H:i:s', $slotEnd),
                        'display' => formatTime(date('H:i:s', $slotStart)) . ' - ' . formatTime(date('H:i:s', $slotEnd)),
                        'tipo' => 'normal'
                    ];
                }
                
                $currentTime += 15 * 60;
            }
        } else {
            // Sin bloqueo: rango continuo
            while ($currentTime + ($duracion * 60) <= $endTime) {
                $slotStart = $currentTime;
                $slotEnd = $currentTime + ($duracion * 60);
                
                if ($isSlotAvailable($slotStart, $slotEnd)) {
                    $slots[] = [
                        'hora_inicio' => date('H:i:s', $slotStart),
                        'hora_fin' => date('H:i:s', $slotEnd),
                        'display' => formatTime(date('H:i:s', $slotStart)) . ' - ' . formatTime(date('H:i:s', $slotEnd)),
                        'tipo' => 'normal'
                    ];
                }
                
                $currentTime += 15 * 60;
            }
        }
        } // Fin de generarSlotsNormales
        
        // 2. Slots del horario de emergencia (si está activo y el servicio es de emergencia)
        if ($generarSlotsEmergencia && $schedule['emergencia_activa'] && $schedule['hora_inicio_emergencia'] && $schedule['hora_fin_emergencia']) {
            $emergencyStart = strtotime($fecha . ' ' . $schedule['hora_inicio_emergencia']);
            $emergencyEnd = strtotime($fecha . ' ' . $schedule['hora_fin_emergencia']);
            
            $currentTime = $emergencyStart;
            while ($currentTime + ($duracion * 60) <= $emergencyEnd) {
                $slotStart = $currentTime;
                $slotEnd = $currentTime + ($duracion * 60);
                
                if ($isSlotAvailable($slotStart, $slotEnd)) {
                    $slots[] = [
                        'hora_inicio' => date('H:i:s', $slotStart),
                        'hora_fin' => date('H:i:s', $slotEnd),
                        'display' => '🚨 ' . formatTime(date('H:i:s', $slotStart)) . ' - ' . formatTime(date('H:i:s', $slotEnd)) . ' (Emergencia)',
                        'tipo' => 'emergencia'
                    ];
                }
                
                $currentTime += 15 * 60;
            }
        }
        
        // Ordenar slots por hora
        usort($slots, function($a, $b) {
            return strcmp($a['hora_inicio'], $b['hora_inicio']);
        });
        
        // DEBUG: Log de resultados
        error_log("[AVAILABILITY DEBUG] Total slots generados: " . count($slots));
        
        $message = null;
        $reason = null;
        if (empty($slots)) {
            $reason = 'no_available_slots';
            $rangeStart = null;
            $rangeEnd = null;

            if ($esServicioEmergencia && !empty($schedule['hora_inicio_emergencia']) && !empty($schedule['hora_fin_emergencia'])) {
                $rangeStart = strtotime($fecha . ' ' . $schedule['hora_inicio_emergencia']);
                $rangeEnd = strtotime($fecha . ' ' . $schedule['hora_fin_emergencia']);
            } elseif (!$esServicioEmergencia) {
                $rangeStart = strtotime($fecha . ' ' . $schedule['hora_inicio']);
                $rangeEnd = strtotime($fecha . ' ' . $schedule['hora_fin']);
            }

            if ($esServicioEmergencia && (!$schedule['emergencia_activa'] || !$schedule['hora_inicio_emergencia'] || !$schedule['hora_fin_emergencia'])) {
                $message = 'Este servicio requiere un horario de emergencia, pero no hay uno configurado para este día.';
            } elseif ($rangeStart && $rangeEnd && (($rangeEnd - $rangeStart) < ($duracion * 60))) {
                $message = 'La duración del servicio es mayor que el horario disponible configurado para este día.';
            } elseif ($fecha === date('Y-m-d') && $rangeEnd && $rangeEnd <= time()) {
                $message = 'El horario de atención de hoy ya terminó. Selecciona otra fecha.';
            } elseif (!empty($existingAppointments) || !empty($existingBlocks) || !empty($schedule['bloqueo_activo'])) {
                $message = 'No quedan espacios que permitan acomodar la duración de la cita; los horarios están ocupados o bloqueados.';
            } else {
                $message = $fecha === date('Y-m-d')
                    ? 'Ya no queda tiempo suficiente hoy para completar la duración de esta cita.'
                    : 'No hay un espacio continuo suficiente para completar la duración de esta cita.';
            }
        }

        $this->json([
            'slots' => $slots,
            'reason' => $reason,
            'message' => $message,
            'debug' => [
                'fecha' => $fecha,
                'horario_normal' => $schedule['hora_inicio'] . ' - ' . $schedule['hora_fin'],
                'horario_emergencia' => ($schedule['emergencia_activa'] ? ($schedule['hora_inicio_emergencia'] . ' - ' . $schedule['hora_fin_emergencia']) : 'Inactivo'),
                'bloqueo' => ($schedule['bloqueo_activo'] ? ($schedule['hora_inicio_bloqueo'] . ' - ' . $schedule['hora_fin_bloqueo']) : 'Ninguno'),
                'citas_existentes' => count($existingAppointments),
                'duracion_servicio' => $duracion . ' min',
                'total_slots_generados' => count($slots)
            ]
        ]);
    }
    
    /**
     * Obtener especialistas de una sucursal
     */
    public function specialists() {
        $sucursal_id = $this->get('sucursal_id');
        
        if (!$sucursal_id) {
            $this->json(['error' => 'Sucursal no especificada'], 400);
        }
        
        $specialists = $this->db->fetchAll(
            "SELECT e.id, e.profesion, e.especialidad, e.calificacion_promedio,
                    u.nombre, u.apellidos
             FROM especialistas e
             JOIN usuarios u ON e.usuario_id = u.id
             JOIN sucursales s ON e.sucursal_id = s.id
             WHERE e.sucursal_id = ? AND e.activo = 1 AND e.autorizado = 1
               AND u.activo = 1 AND s.activo = 1 AND s.autorizado = 1
             ORDER BY u.nombre, u.apellidos",
            [$sucursal_id]
        );
        
        $this->json(['specialists' => $specialists]);
    }
    
    /**
     * Obtener servicios de un especialista
     */
    public function services() {
        $especialista_id = $this->get('especialista_id');
        $fecha = $this->get('fecha'); // Opcional: para filtrar por horario de emergencia
        $hora = $this->get('hora'); // Opcional: para filtrar por horario de emergencia
        $es_consulta_extraordinaria = $this->get('es_extraordinaria') === '1'; // Nuevo parámetro
        
        if ($especialista_id) {
            // Determinar si estamos en horario de emergencia
            $es_horario_emergencia = false;
            
            if ($fecha && $hora) {
                $dia_semana = date('N', strtotime($fecha)); // 1=Lunes, 7=Domingo
                $hora_consulta = strtotime($fecha . ' ' . $hora);
                
                // Verificar si el especialista tiene horario de emergencia activo para ese día
                $horario = $this->db->fetch(
                    "SELECT hora_inicio, hora_fin, 
                            hora_inicio_emergencia, hora_fin_emergencia, emergencia_activa
                     FROM horarios_especialistas
                     WHERE especialista_id = ? AND dia_semana = ? AND activo = 1",
                    [$especialista_id, $dia_semana]
                );
                
                if ($horario && $horario['emergencia_activa']) {
                    $hora_inicio_normal = strtotime($fecha . ' ' . $horario['hora_inicio']);
                    $hora_fin_normal = strtotime($fecha . ' ' . $horario['hora_fin']);
                    $hora_inicio_emergencia = $horario['hora_inicio_emergencia'] ? strtotime($fecha . ' ' . $horario['hora_inicio_emergencia']) : null;
                    $hora_fin_emergencia = $horario['hora_fin_emergencia'] ? strtotime($fecha . ' ' . $horario['hora_fin_emergencia']) : null;
                    
                    // Si la hora está fuera del horario normal pero dentro del horario de emergencia
                    if ($hora_inicio_emergencia && $hora_fin_emergencia) {
                        if (($hora_consulta < $hora_inicio_normal || $hora_consulta >= $hora_fin_normal) &&
                            ($hora_consulta >= $hora_inicio_emergencia && $hora_consulta < $hora_fin_emergencia)) {
                            $es_horario_emergencia = true;
                        }
                    }
                }
            }
            
            // Filtrar servicios según si es consulta extraordinaria, horario de emergencia o normal
            // Si es consulta extraordinaria: SOLO mostrar servicios de categoría 9 (Extraordinario)
            // Si NO es consulta extraordinaria: EXCLUIR servicios de categoría 9
            
            if ($es_consulta_extraordinaria) {
                // CONSULTA EXTRAORDINARIA: Solo servicios de categoría 9
                $services = $this->db->fetchAll(
                    "SELECT s.id, s.nombre, s.descripcion, s.duracion_minutos, s.precio,
                            COALESCE(es.precio_personalizado, s.precio) as precio,
                            COALESCE(es.duracion_personalizada, s.duracion_minutos) as duracion_minutos,
                            c.nombre as categoria_nombre, c.id as categoria_id,
                            es.es_emergencia
                     FROM servicios s
                     JOIN especialistas_servicios es ON s.id = es.servicio_id
                     JOIN especialistas e ON e.id = es.especialista_id
                     JOIN usuarios u ON u.id = e.usuario_id
                     JOIN sucursales suc ON suc.id = e.sucursal_id
                     JOIN categorias_servicios c ON s.categoria_id = c.id
                     WHERE es.especialista_id = ? AND s.activo = 1 AND es.activo = 1 AND c.id = 9
                       AND e.activo = 1 AND e.autorizado = 1 AND u.activo = 1
                       AND suc.activo = 1 AND suc.autorizado = 1
                     ORDER BY s.nombre",
                    [$especialista_id]
                );
            } else if ($fecha && $hora) {
                // Filtrar por tipo de horario (EXCLUYENDO categoría 9)
                $services = $this->db->fetchAll(
                    "SELECT s.id, s.nombre, s.descripcion, s.duracion_minutos, s.precio,
                            COALESCE(es.precio_personalizado, s.precio) as precio,
                            COALESCE(es.duracion_personalizada, s.duracion_minutos) as duracion_minutos,
                            c.nombre as categoria_nombre, c.id as categoria_id,
                            es.es_emergencia
                     FROM servicios s
                     JOIN especialistas_servicios es ON s.id = es.servicio_id
                     JOIN especialistas e ON e.id = es.especialista_id
                     JOIN usuarios u ON u.id = e.usuario_id
                     JOIN sucursales suc ON suc.id = e.sucursal_id
                     JOIN categorias_servicios c ON s.categoria_id = c.id
                     WHERE es.especialista_id = ? AND s.activo = 1 AND es.activo = 1 
                           AND es.es_emergencia = ? AND c.id != 9
                           AND e.activo = 1 AND e.autorizado = 1 AND u.activo = 1
                           AND suc.activo = 1 AND suc.autorizado = 1
                     ORDER BY c.nombre, s.nombre",
                    [$especialista_id, $es_horario_emergencia ? 1 : 0]
                );
            } else {
                // Mostrar todos los servicios EXCEPTO categoría 9 (normal y emergencia)
                $services = $this->db->fetchAll(
                    "SELECT s.id, s.nombre, s.descripcion, s.duracion_minutos, s.precio,
                            COALESCE(es.precio_personalizado, s.precio) as precio,
                            COALESCE(es.duracion_personalizada, s.duracion_minutos) as duracion_minutos,
                            c.nombre as categoria_nombre, c.id as categoria_id,
                            es.es_emergencia
                     FROM servicios s
                     JOIN especialistas_servicios es ON s.id = es.servicio_id
                     JOIN especialistas e ON e.id = es.especialista_id
                     JOIN usuarios u ON u.id = e.usuario_id
                     JOIN sucursales suc ON suc.id = e.sucursal_id
                     JOIN categorias_servicios c ON s.categoria_id = c.id
                     WHERE es.especialista_id = ? AND s.activo = 1 AND es.activo = 1 AND c.id != 9
                       AND e.activo = 1 AND e.autorizado = 1 AND u.activo = 1
                       AND suc.activo = 1 AND suc.autorizado = 1
                     ORDER BY es.es_emergencia DESC, c.nombre, s.nombre",
                    [$especialista_id]
                );
            }
        } else {
            $services = $this->db->fetchAll(
                "SELECT s.*, c.nombre as categoria_nombre
                 FROM servicios s
                 JOIN categorias_servicios c ON s.categoria_id = c.id
                 WHERE s.activo = 1
                 ORDER BY c.nombre, s.nombre"
            );
        }
        
        $this->json(['services' => $services]);
    }
    
    /**
     * Obtener especialista_id según usuario_id y sucursal_id
     * Para especialistas que trabajan en múltiples sucursales
     */
    public function getSpecialistBranch() {
        $usuario_id = $this->get('usuario_id');
        $sucursal_id = $this->get('sucursal_id');
        
        if (!$usuario_id || !$sucursal_id) {
            $this->json(['error' => 'Parámetros incompletos'], 400);
        }
        
        $specialist = $this->db->fetch(
            "SELECT id FROM especialistas WHERE usuario_id = ? AND sucursal_id = ? AND activo = 1",
            [$usuario_id, $sucursal_id]
        );
        
        if ($specialist) {
            $this->json(['especialista_id' => $specialist['id']]);
        } else {
            $this->json(['error' => 'Especialista no encontrado para esta sucursal'], 404);
        }
    }
    
    /**
     * Obtener sucursal del especialista según el día de la semana
     */
    public function getSpecialistBranchByDay() {
        $usuario_id = $this->get('usuario_id');
        $dia_semana = $this->get('dia_semana'); // 1-7 (lunes-domingo)
        
        if (!$usuario_id || !$dia_semana) {
            $this->json(['error' => 'Parámetros incompletos'], 400);
        }
        
        // Buscar en qué sucursal trabaja el especialista ese día
        $result = $this->db->fetch(
            "SELECT e.id as especialista_id, e.sucursal_id, s.nombre as sucursal_nombre
             FROM especialistas e
             INNER JOIN horarios_especialistas he ON he.especialista_id = e.id
             INNER JOIN sucursales s ON s.id = e.sucursal_id
             WHERE e.usuario_id = ? AND he.dia_semana = ? AND e.activo = 1
             LIMIT 1",
            [$usuario_id, $dia_semana]
        );
        
        if ($result) {
            $this->json([
                'especialista_id' => $result['especialista_id'],
                'sucursal_id' => $result['sucursal_id'],
                'sucursal_nombre' => $result['sucursal_nombre']
            ]);
        } else {
            $this->json(['error' => 'No se encontró horario para este día'], 404);
        }
    }
    
    /**
     * Obtener TODAS las sucursales de un especialista (para citas extraordinarias)
     */
    public function getSpecialistBranches() {
        $usuario_id = $this->get('usuario_id');
        
        if (!$usuario_id) {
            $this->json(['error' => 'Parámetro usuario_id requerido'], 400);
        }
        
        // Obtener todas las sucursales donde el especialista está registrado
        $sucursales = $this->db->fetchAll(
            "SELECT e.id as especialista_id, e.sucursal_id, s.nombre, s.direccion
             FROM especialistas e
             INNER JOIN sucursales s ON s.id = e.sucursal_id
             WHERE e.usuario_id = ? AND e.activo = 1 AND s.activo = 1
             ORDER BY s.nombre",
            [$usuario_id]
        );
        
        $this->json($sucursales);
    }
    
    /**
     * Obtener sucursales
     */
    public function branches() {
        $branches = $this->db->fetchAll(
            "SELECT id, nombre, direccion, ciudad, telefono, horario_apertura, horario_cierre
             FROM sucursales WHERE activo = 1 ORDER BY nombre"
        );
        
        $this->json(['branches' => $branches]);
    }
    
    /**
     * Crear sucursal vía API
     */
    public function createBranch() {
        $this->requireAuth();
        $this->requireRole([ROLE_SUPERADMIN, ROLE_BRANCH_ADMIN]);
        
        // Leer datos JSON
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nombre']) || empty($data['nombre'])) {
            $this->json(['success' => false, 'message' => 'El nombre es obligatorio'], 400);
        }
        
        try {
            $id = $this->db->insert(
                "INSERT INTO sucursales (nombre, direccion, ciudad, estado, codigo_postal, telefono, email, horario_apertura, horario_cierre, activo) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)",
                [
                    $data['nombre'],
                    $data['direccion'] ?? null,
                    $data['ciudad'] ?? null,
                    $data['estado'] ?? null,
                    $data['codigo_postal'] ?? null,
                    $data['telefono'] ?? null,
                    $data['email'] ?? null,
                    $data['horario_apertura'] ?? '08:00',
                    $data['horario_cierre'] ?? '20:00'
                ]
            );
            
            logAction('branch_create', 'Sucursal creada vía API: ' . $data['nombre']);
            $this->json(['success' => true, 'id' => $id]);
        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => 'Error al crear la sucursal'], 500);
        }
    }
    
    /**
     * Crear servicio vía API
     */
    public function createService() {
        $this->requireAuth();
        $this->requireRole([ROLE_SUPERADMIN, ROLE_BRANCH_ADMIN]);
        
        // Leer datos JSON
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['nombre']) || empty($data['nombre'])) {
            $this->json(['success' => false, 'message' => 'El nombre es obligatorio'], 400);
        }
        
        if (!isset($data['categoria_id']) || empty($data['categoria_id'])) {
            $this->json(['success' => false, 'message' => 'La categoría es obligatoria'], 400);
        }
        
        try {
            $id = $this->db->insert(
                "INSERT INTO servicios (categoria_id, nombre, descripcion, duracion_minutos, precio, precio_oferta, activo) 
                 VALUES (?, ?, ?, ?, ?, ?, 1)",
                [
                    $data['categoria_id'],
                    $data['nombre'],
                    $data['descripcion'] ?? null,
                    $data['duracion_minutos'] ?? 30,
                    $data['precio'] ?? 0,
                    $data['precio_oferta'] ?? null
                ]
            );
            
            logAction('service_create', 'Servicio creado vía API: ' . $data['nombre']);
            $this->json(['success' => true, 'id' => $id]);
        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => 'Error al crear el servicio'], 500);
        }
    }
    
    /**
     * Verificar nuevas reservas pendientes para el especialista actual
     */
    public function checkNewReservations() {
        try {
            // Solo especialistas pueden recibir notificaciones de nuevas reservas
            if (!isLoggedIn()) {
                $this->json(['hasNew' => false]);
                return;
            }
            
            $user = currentUser();
            
            // Solo para especialistas
            if ($user['rol_id'] != ROLE_SPECIALIST) {
                $this->json(['hasNew' => false]);
                return;
            }
            
            // Obtener el ID del especialista
            $especialista = $this->db->fetch(
                "SELECT id FROM especialistas WHERE usuario_id = ? AND activo = 1",
                [$user['id']]
            );
            
            if (!$especialista) {
                $this->json(['hasNew' => false]);
                return;
            }
            
            // Obtener el último ID notificado desde el parámetro (para evitar duplicados)
            $lastNotifiedId = (int)($this->get('last_id') ?? 0);
            
            // Buscar la reserva pendiente más reciente que no haya sido notificada
            $newReservation = $this->db->fetch(
                "SELECT r.id, r.codigo, r.fecha_cita, r.hora_inicio, r.hora_fin,
                        r.precio_total, r.created_at,
                        COALESCE(u.nombre, r.nombre_cliente) as cliente_nombre,
                        s.nombre as servicio_nombre,
                        suc.nombre as sucursal_nombre
                 FROM reservaciones r
                 LEFT JOIN usuarios u ON r.cliente_id = u.id
                 LEFT JOIN servicios s ON r.servicio_id = s.id
                 LEFT JOIN sucursales suc ON r.sucursal_id = suc.id
                 WHERE r.especialista_id = ?
                 AND r.estado = 'pendiente'
                 AND r.id > ?
                 AND r.created_at >= NOW() - INTERVAL 10 MINUTE
                 ORDER BY r.created_at ASC
                 LIMIT 1",
                [$especialista['id'], $lastNotifiedId]
            );
            
            if ($newReservation) {
                // Formatear la información de la reserva
                $this->json([
                    'hasNew' => true,
                    'reservation' => [
                        'id' => $newReservation['id'],
                        'codigo' => $newReservation['codigo'],
                        'cliente' => $newReservation['cliente_nombre'] ?? 'Sin nombre',
                        'servicio' => $newReservation['servicio_nombre'] ?? 'Sin servicio',
                        'sucursal' => $newReservation['sucursal_nombre'] ?? 'Sin sucursal',
                        'fecha' => formatDate($newReservation['fecha_cita'], 'd/m/Y'),
                        'hora' => formatTime($newReservation['hora_inicio']) . ' - ' . formatTime($newReservation['hora_fin']),
                        'precio' => formatMoney($newReservation['precio_total']),
                        'created_at' => $newReservation['created_at']
                    ]
                ]);
            } else {
                $this->json(['hasNew' => false]);
            }
        } catch (Exception $e) {
            // Log del error para debugging
            error_log('[NOTIFICATION ERROR] ' . $e->getMessage());
            error_log('[NOTIFICATION ERROR] Trace: ' . $e->getTraceAsString());
            
            // Siempre retornar JSON válido
            $this->json(['hasNew' => false, 'error' => $e->getMessage()]);
        }
    }
    
    /**
     * Obtener horario del especialista para una fecha específica
     */
    public function getSpecialistSchedule() {
        $especialistaId = $this->get('especialista_id');
        $fecha = $this->get('fecha');
        
        if (!$especialistaId || !$fecha) {
            $this->json(['error' => 'Parámetros incompletos'], 400);
            return;
        }
        
        // Obtener día de la semana (1=Lunes, 7=Domingo)
        $dayOfWeek = date('N', strtotime($fecha));
        
        // Obtener horario del especialista para ese día
        $horario = $this->db->fetch(
            "SELECT hora_inicio, hora_fin, dia_semana FROM horarios_especialistas 
             WHERE especialista_id = ? AND dia_semana = ? AND activo = 1",
            [$especialistaId, $dayOfWeek]
        );
        
        if (!$horario) {
            $this->json([
                'horario' => null,
                'mensaje' => 'No hay horario configurado para este día'
            ]);
            return;
        }
        
        // Verificar si hay bloqueo ese día
        $bloqueo = $this->db->fetch(
            "SELECT id FROM bloqueos_horario 
             WHERE especialista_id = ? AND ? BETWEEN DATE(fecha_inicio) AND DATE(fecha_fin)",
            [$especialistaId, $fecha]
        );
        
        if ($bloqueo) {
            $this->json([
                'horario' => null,
                'mensaje' => 'El especialista tiene un bloqueo en esta fecha'
            ]);
            return;
        }
        
        $this->json([
            'horario' => [
                'hora_inicio' => $horario['hora_inicio'],
                'hora_fin' => $horario['hora_fin'],
                'dia_semana' => $horario['dia_semana']
            ]
        ]);
    }
}
