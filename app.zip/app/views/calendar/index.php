<div class="space-y-6">
    <!-- Header with Filters -->
    <div class="bg-white rounded-xl shadow-sm p-6">
        <div class="flex items-center justify-between mb-6">
            <div>
                <h2 class="text-2xl font-bold text-gray-800">
                    <i class="fas fa-calendar-alt text-primary mr-2"></i>Calendario de Citas
                </h2>
                <p class="text-sm text-gray-500 mt-1">Visualiza y gestiona tus citas programadas</p>
            </div>
        </div>
        
        <!-- Filters -->
        <div class="flex flex-wrap gap-4">
            <?php if (!empty($branches)): ?>
            <div class="flex-1 min-w-[200px]">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-building text-gray-400 mr-1"></i>Sucursal
                </label>
                <select id="filter_sucursal" 
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition" 
                        onchange="filterCalendar('branch')">
                    <option value="">
                        <?php if ($user['rol_id'] == ROLE_SPECIALIST): ?>
                        Todas mis sucursales
                        <?php else: ?>
                        Todas las sucursales
                        <?php endif; ?>
                    </option>
                    <?php foreach ($branches as $branch): ?>
                    <option value="<?= $branch['id'] ?>"><?= e($branch['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($specialists)): ?>
            <div class="flex-1 min-w-[200px]">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-user-md text-gray-400 mr-1"></i>Especialista
                </label>
                <select id="filter_especialista" 
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition" 
                        onchange="filterCalendar('specialist')">
                    <option value="">Todos los especialistas</option>
                    <?php foreach ($specialists as $spec): ?>
                    <option value="<?= $spec['id'] ?>" data-branch-id="<?= $spec['sucursal_id'] ?? '' ?>">
                        <?= e($spec['nombre'] . ' ' . $spec['apellidos']) ?>
                        <?= isset($spec['sucursal_nombre']) ? ' - ' . e($spec['sucursal_nombre']) : '' ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            
            <!-- Colores de Sucursales -->
            <?php if (!empty($branches) && count($branches) > 1): ?>
            <div class="flex-1 min-w-[200px]">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-palette text-gray-400 mr-1"></i>Colores de Sucursales
                </label>
                <button onclick="toggleColorPicker()" 
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg hover:bg-gray-50 transition flex items-center justify-between">
                    <span class="text-sm text-gray-700">Cambiar colores</span>
                    <i class="fas fa-chevron-down text-gray-400" id="colorPickerIcon"></i>
                </button>
                <div id="colorPickerPanel" class="hidden mt-2 p-4 bg-gray-50 border border-gray-200 rounded-lg space-y-2">
                    <?php foreach ($branches as $branch): ?>
                    <div class="flex items-center justify-between">
                        <span class="text-sm text-gray-700 flex-1"><?= e($branch['nombre']) ?></span>
                        <input type="color" 
                               value="<?= e($branch['color'] ?? '#3B82F6') ?>" 
                               data-branch-id="<?= $branch['id'] ?>"
                               onchange="updateBranchColor(<?= $branch['id'] ?>, this.value)"
                               class="h-8 w-16 border border-gray-300 rounded cursor-pointer">
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Estado Legend -->
            <div class="flex-1 min-w-[200px]">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-info-circle text-gray-400 mr-1"></i>Leyenda de Estados
                </label>
                <div class="flex flex-wrap gap-2">
                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium" style="background-color: #F59E0B; color: white;">
                        <i class="fas fa-clock mr-1"></i>Pendiente
                    </span>
                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium" style="background-color: #10B981; color: white;">
                        <i class="fas fa-check mr-1"></i>Confirmada
                    </span>
                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium" style="background-color: #6B7280; color: white;">
                        <i class="fas fa-check-double mr-1"></i>Completada
                    </span>
                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium" style="background-color: #F97316; color: white;">
                        <i class="fas fa-user-times mr-1"></i>No Asisti&oacute;
                    </span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Calendar Container -->
    <div class="bg-white rounded-xl shadow-sm p-6">
        <div id="calendar"></div>
    </div>
</div>

<style>
/* Hacer que los días del calendario sean claramente clickeables */
.fc-daygrid-day {
    cursor: pointer;
    transition: background-color 0.2s ease;
}

.fc-daygrid-day:hover {
    background-color: rgba(59, 130, 246, 0.05) !important;
}

.fc-daygrid-day.fc-day-past {
    cursor: not-allowed;
    opacity: 0.6;
}

.fc-daygrid-day.fc-day-past:hover {
    background-color: transparent !important;
}

/* Los eventos mantienen su propio cursor */
.fc-event {
    cursor: pointer !important;
}

.fc-event:hover {
    opacity: 0.9;
}

/* Indicador visual sutil en días vacíos */
.fc-daygrid-day-frame {
    position: relative;
}

.fc-daygrid-day:not(.fc-day-past) .fc-daygrid-day-number {
    transition: all 0.2s ease;
}

.fc-daygrid-day:not(.fc-day-past):hover .fc-daygrid-day-number {
    transform: scale(1.1);
    font-weight: 600;
    color: #3B82F6;
}

/* Estilo para horas fuera de horario disponible (non-business hours) */
.fc-non-business {
    background-color: #e5e7eb !important; /* gris oscuro */
    opacity: 0.7;
}

/* En vista de semana/día, hacer más evidente las horas no disponibles */
.fc-timegrid .fc-non-business {
    background-color: #d1d5db !important; /* gris más oscuro */
    background-image: repeating-linear-gradient(
        45deg,
        transparent,
        transparent 10px,
        rgba(0, 0, 0, 0.03) 10px,
        rgba(0, 0, 0, 0.03) 20px
    );
}

/* Asegurar que las celdas de horario disponible se vean claras */
.fc-timegrid-slot:not(.fc-non-business) {
    background-color: #ffffff;
}

/* Altura compacta de cada slot de tiempo para facilitar navegación */
.fc-timegrid-slot {
    height: 30px !important;
    min-height: 30px !important;
}

.fc-timegrid-slot-lane {
    height: 30px !important;
}

/* Alternar tonos de gris cada hora (cada 4 slots de 15 min) */
.fc-timegrid-slot:nth-child(8n+1),
.fc-timegrid-slot:nth-child(8n+2),
.fc-timegrid-slot:nth-child(8n+3),
.fc-timegrid-slot:nth-child(8n+4) {
    background-color: #f9fafb !important;
}

.fc-timegrid-slot:nth-child(8n+5),
.fc-timegrid-slot:nth-child(8n+6),
.fc-timegrid-slot:nth-child(8n+7),
.fc-timegrid-slot:nth-child(8n+8) {
    background-color: #f3f4f6 !important;
}

/* Altura mínima de eventos en vista semanal para mostrar dos líneas */
.fc-timegrid-event {
    min-height: 35px !important;
    padding: 2px 4px !important;
    min-width: 140px !important; /* Ancho mínimo para que se vea el texto completo */
    box-shadow: 0 2px 4px rgba(0,0,0,0.15) !important; /* Sombra para diferenciar eventos solapados */
}

.fc-timegrid-event .fc-event-main {
    padding: 0 !important;
    width: 100%;
}

.fc-timegrid-event .fc-event-title {
    white-space: normal !important;
    overflow: visible !important;
    line-height: 1.25 !important;
    font-size: 0.8em !important;
    text-align: left !important;
    word-wrap: break-word !important;
}

/* Cuando hay eventos simultáneos, ajustar posición */
.fc-timegrid-col-events {
    margin-right: 0 !important;
}

/* Animación de pulso para horario pre-seleccionado */
@keyframes pulse {
    0%, 100% {
        transform: scale(1);
        box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7);
    }
    50% {
        transform: scale(1.05);
        box-shadow: 0 0 0 10px rgba(59, 130, 246, 0);
    }
}

/* Estilos para bloqueos visuales */
.fc-bg-event.bloqueo-visual {
    opacity: 1 !important;
    background-image: repeating-linear-gradient(
        45deg,
        transparent,
        transparent 10px,
        rgba(220, 38, 38, 0.02) 10px,
        rgba(220, 38, 38, 0.02) 20px
    ) !important;
    border-left: 2px solid rgba(220, 38, 38, 0.15) !important;
    border-right: 2px solid rgba(220, 38, 38, 0.15) !important;
}

/* Permitir que se pueda hacer clic sobre los bloqueos visuales */
.fc-bg-event {
    pointer-events: none !important;
}
</style>

<!-- Action Selection Modal -->
<div id="actionModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-2xl max-w-md w-full transform transition-all">
        <div class="p-6 bg-gradient-to-r from-blue-500 to-blue-600 rounded-t-2xl">
            <div class="flex justify-between items-center">
                <h3 class="text-xl font-bold text-white flex items-center">
                    <i class="fas fa-calendar-plus mr-3"></i>
                    <span>¿Qué deseas hacer?</span>
                </h3>
                <button onclick="closeActionModal()" class="text-white hover:text-gray-200 transition">
                    <i class="fas fa-times text-2xl"></i>
                </button>
            </div>
            <p class="text-blue-100 text-sm mt-2" id="action-date-display">Fecha seleccionada</p>
        </div>
        
        <div class="p-6 space-y-4">
            <button onclick="selectAgendarAction()" 
                    class="w-full p-6 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-xl transition-all transform hover:scale-105 shadow-lg hover:shadow-xl">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="bg-white bg-opacity-20 rounded-full p-3 mr-4">
                            <i class="fas fa-calendar-check text-2xl"></i>
                        </div>
                        <div class="text-left">
                            <h4 class="text-lg font-bold">Agendar Cita</h4>
                            <p class="text-sm text-green-100">Programar nueva reservación</p>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right text-xl"></i>
                </div>
            </button>
            
            <button onclick="selectBloquearAction()" 
                    class="w-full p-6 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white rounded-xl transition-all transform hover:scale-105 shadow-lg hover:shadow-xl">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="bg-white bg-opacity-20 rounded-full p-3 mr-4">
                            <i class="fas fa-ban text-2xl"></i>
                        </div>
                        <div class="text-left">
                            <h4 class="text-lg font-bold">Bloquear Horario</h4>
                            <p class="text-sm text-red-100">Marcar tiempo no disponible</p>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right text-xl"></i>
                </div>
            </button>
            
            <button onclick="selectCirugiaAction()" 
                    class="w-full p-6 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white rounded-xl transition-all transform hover:scale-105 shadow-lg hover:shadow-xl">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="bg-white bg-opacity-20 rounded-full p-3 mr-4">
                            <i class="fas fa-user-md text-2xl"></i>
                        </div>
                        <div class="text-left">
                            <h4 class="text-lg font-bold">Programar Cirug&iacute;a</h4>
                            <p class="text-sm text-purple-100">Agendar procedimiento quir&uacute;rgico</p>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right text-xl"></i>
                </div>
            </button>
            
            <button onclick="selectConsultaExtraordinariaAction()" 
                    class="w-full p-6 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white rounded-xl transition-all transform hover:scale-105 shadow-lg hover:shadow-xl">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="bg-white bg-opacity-20 rounded-full p-3 mr-4">
                            <i class="fas fa-user-clock text-2xl"></i>
                        </div>
                        <div class="text-left">
                            <h4 class="text-lg font-bold">Cita Extraordinaria</h4>
                            <p class="text-sm text-orange-100">Cita fuera de horario normal</p>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right text-xl"></i>
                </div>
            </button>
        </div>
    </div>
</div>

<!-- Block Schedule Modal -->
<div id="blockModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-2xl max-w-lg w-full transform transition-all">
        <div class="p-6 bg-gradient-to-r from-red-500 to-red-600 rounded-t-2xl">
            <div class="flex justify-between items-center">
                <h3 class="text-xl font-bold text-white flex items-center">
                    <i class="fas fa-ban mr-3"></i>
                    <span>Bloquear Horario</span>
                </h3>
                <button onclick="closeBlockModal()" class="text-white hover:text-gray-200 transition">
                    <i class="fas fa-times text-2xl"></i>
                </button>
            </div>
            <p class="text-red-100 text-sm mt-2" id="block-date-display">Fecha seleccionada</p>
        </div>
        
        <form id="blockScheduleForm" class="p-6 space-y-6">
            <!-- Sucursal (si tiene múltiples) -->
            <?php if (!empty($branches) && count($branches) > 1): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-building mr-1"></i>Sucursal *
                </label>
                <select id="block_sucursal" required
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                    <option value="">-- Seleccione una sucursal --</option>
                    <?php foreach ($branches as $branch): ?>
                    <option value="<?= $branch['id'] ?>"><?= e($branch['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
                <p class="text-xs text-gray-500 mt-1">Dejar vacío para bloquear en todas las sucursales</p>
            </div>
            <?php endif; ?>
            
            <!-- Hora Inicio -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-clock mr-1"></i>Hora de Inicio *
                </label>
                <input type="time" id="block_hora_inicio" required
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
            </div>
            
            <!-- Hora Fin -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-clock mr-1"></i>Hora de Fin *
                </label>
                <input type="time" id="block_hora_fin" required
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
            </div>
            
            <!-- Tipo -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-tag mr-1"></i>Tipo de Bloqueo *
                </label>
                <select id="block_tipo" required
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                    <option value="puntual">Bloqueo Puntual</option>
                    <option value="personal">Asunto Personal</option>
                    <option value="pausa">Pausa/Descanso</option>
                    <option value="otro">Otro</option>
                </select>
            </div>
            
            <!-- Motivo -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-comment mr-1"></i>Motivo (opcional)
                </label>
                <textarea id="block_motivo" rows="2"
                          placeholder="Ej: Reunión importante, cita médica, etc."
                          class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"></textarea>
            </div>
            
            <input type="hidden" id="block_fecha" value="">
            <input type="hidden" id="block_especialista_id" value="<?= $currentSpecialistId ?? '' ?>">
        </form>
        
        <div class="p-6 bg-gray-50 border-t rounded-b-2xl">
            <div class="flex justify-end gap-3">
                <button onclick="closeBlockModal()" class="px-6 py-2.5 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
                    <i class="fas fa-times mr-2"></i>Cancelar
                </button>
                <button onclick="submitBlockSchedule()" class="px-6 py-2.5 bg-red-600 text-white rounded-lg hover:bg-red-700 transition shadow-md hover:shadow-lg">
                    <i class="fas fa-ban mr-2"></i>Bloquear Horario
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Surgery Modal -->
<div id="surgeryModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-2xl max-w-lg w-full transform transition-all">
        <div class="p-6 bg-gradient-to-r from-purple-500 to-purple-600 rounded-t-2xl">
            <div class="flex justify-between items-center">
                <h3 class="text-xl font-bold text-white flex items-center">
                    <i class="fas fa-user-md mr-3"></i>
                    <span>Programar Cirug&iacute;a</span>
                </h3>
                <button onclick="closeSurgeryModal()" class="text-white hover:text-gray-200 transition">
                    <i class="fas fa-times text-2xl"></i>
                </button>
            </div>
            <p class="text-purple-100 text-sm mt-2" id="surgery-date-display">Fecha seleccionada</p>
        </div>
        
        <form id="surgeryScheduleForm" class="p-6 space-y-6">
            <!-- Sucursal (solo si hay múltiples) -->
            <?php if (!empty($branches) && count($branches) > 1): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-building mr-1"></i>Sucursal (opcional)
                </label>
                <select id="surgery_sucursal"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                    <option value="">Todas las sucursales</option>
                    <?php foreach ($branches as $branch): ?>
                    <option value="<?= $branch['id'] ?>"><?= e($branch['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
                <p class="text-xs text-gray-500 mt-1">Dejar vacío para bloquear en todas las sucursales</p>
            </div>
            <?php endif; ?>
            
            <!-- Hora Inicio -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-clock mr-1"></i>Hora de Inicio *
                </label>
                <input type="time" id="surgery_hora_inicio" required
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
            </div>
            
            <!-- Hora Fin -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-clock mr-1"></i>Hora de Fin *
                </label>
                <input type="time" id="surgery_hora_fin" required
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
            </div>
            
            <!-- Asistentes -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-users mr-1"></i>Asistentes (opcional)
                </label>
                <textarea id="surgery_asistentes" rows="2"
                          placeholder="Ej: Dr. García, Enf. María López, etc."
                          class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"></textarea>
            </div>
            
            <input type="hidden" id="surgery_fecha" value="">
            <input type="hidden" id="surgery_especialista_id" value="<?= $currentSpecialistId ?? '' ?>">
            <input type="hidden" id="surgery_tipo" value="cirugia">
        </form>
        
        <div class="p-6 bg-gray-50 border-t rounded-b-2xl">
            <div class="flex justify-end gap-3">
                <button onclick="closeSurgeryModal()" class="px-6 py-2.5 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
                    <i class="fas fa-times mr-2"></i>Cancelar
                </button>
                <button onclick="submitSurgerySchedule()" class="px-6 py-2.5 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition shadow-md hover:shadow-lg">
                    <i class="fas fa-user-md mr-2"></i>Programar Cirug&iacute;a
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Create Reservation Modal -->
<div id="createModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto transform transition-all">
        <div id="createModalHeader" class="p-6 bg-gradient-to-r from-green-500 to-green-600 rounded-t-2xl sticky top-0 z-10">
            <div class="flex justify-between items-center">
                <h3 class="text-xl font-bold text-white flex items-center">
                    <i class="fas fa-plus-circle mr-3"></i>
                    <span>Nueva Reservaci&oacute;n</span>
                </h3>
                <button onclick="closeCreateModal()" class="text-white hover:text-gray-200 transition">
                    <i class="fas fa-times text-2xl"></i>
                </button>
            </div>
            <p id="createModalSubtitle" class="text-green-100 text-sm mt-2"><span id="selected-date-display">Fecha seleccionada</span></p>
        </div>
        
        <form id="createReservationForm" class="p-6 space-y-6">
            <!-- Opción: Cita Extraordinaria -->
            <div class="p-4 bg-orange-50 border-l-4 border-orange-400 rounded-lg">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-3">
                        <i class="fas fa-user-clock text-orange-600 text-xl"></i>
                        <div>
                            <label for="create_es_extraordinaria" class="font-semibold text-gray-900 cursor-pointer">
                                Cita Extraordinaria
                            </label>
                            <p class="text-sm text-gray-600">
                                Permite reservar sin validar disponibilidad
                            </p>
                        </div>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input 
                            type="checkbox" 
                            id="create_es_extraordinaria" 
                            name="es_extraordinaria" 
                            value="1"
                            class="sr-only peer"
                            onchange="toggleCreateExtraordinariaWarning(this.checked)"
                        >
                        <div class="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-orange-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-600"></div>
                    </label>
                </div>
                <div id="create_extraordinaria_warning" class="hidden mt-3 p-3 bg-orange-100 border border-orange-300 rounded-lg">
                    <p class="text-sm text-orange-800 flex items-start">
                        <i class="fas fa-exclamation-triangle mr-2 mt-0.5"></i>
                        <span><strong>Advertencia:</strong> Esta cita NO validará horarios disponibles y puede causar empalmes.</span>
                    </p>
                </div>
            </div>
            
            <!-- Opción: Primera Cita -->
            <div class="p-4 bg-blue-50 border-l-4 border-blue-400 rounded-lg">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-3">
                        <i class="fas fa-user-plus text-blue-600 text-xl"></i>
                        <div>
                            <label for="create_primera_consulta" class="font-semibold text-gray-900 cursor-pointer">
                                Primera Cita
                            </label>
                            <p class="text-sm text-gray-600">
                                Marcar si es la primera cita del cliente
                            </p>
                        </div>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input 
                            type="checkbox" 
                            id="create_primera_consulta" 
                            name="primera_consulta" 
                            value="1"
                            class="sr-only peer"
                        >
                        <div class="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                </div>
            </div>
            
            <!-- Cliente -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-user mr-1"></i>Nombre del Cliente *
                </label>
                <input type="text" id="create_nombre_cliente" required
                       placeholder="Ingrese el nombre completo del cliente"
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
            </div>
            
            <!-- Teléfono del Cliente -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-phone mr-1"></i>Teléfono
                </label>
                <input type="tel" id="create_telefono"
                       placeholder="Ej: 3331234567"
                       maxlength="10"
                       pattern="[0-9]{10}"
                       oninput="this.value = this.value.replace(/[^0-9]/g, '').substring(0, 10)"
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                <p class="text-xs text-gray-500 mt-1">10 dígitos (opcional)</p>
            </div>
            
            <!-- Correo del Cliente -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-envelope mr-1"></i>Correo Electrónico
                </label>
                <input type="email" id="create_correo"
                       placeholder="cliente@ejemplo.com"
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
            </div>
            
            <!-- Sucursal -->
            <?php if (!empty($branches)): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-building mr-1"></i>Sucursal *
                </label>
                <select id="create_sucursal" required onchange="handleCreateBranchChange()"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                    <option value="">-- Seleccione una sucursal --</option>
                    <?php foreach ($branches as $branch): ?>
                    <option value="<?= $branch['id'] ?>"><?= e($branch['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <p id="create_selection_message" class="hidden text-sm mt-2"></p>

            <?php if ($user['rol_id'] != ROLE_SPECIALIST): ?>
            <div id="create_specialist_section" style="display:none;">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-user-tie mr-1"></i>Profesionista *
                </label>
                <select id="create_especialista_select" onchange="selectCreateSpecialist(this.value)"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                    <option value="">-- Seleccione un profesionista --</option>
                </select>
            </div>
            <?php endif; ?>
            
            <!-- Servicio -->
            <div id="create_service_section" style="display:none;">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-concierge-bell mr-1"></i>Servicio *
                </label>
                <select id="create_servicio" required onchange="loadTimeSlotsForCreate()"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                    <option value="">-- Seleccione un servicio --</option>
                </select>
                <div id="service_details" class="mt-2 p-3 bg-blue-50 rounded-lg hidden">
                    <p class="text-sm text-gray-700">
                        <strong>Duraci&oacute;n:</strong> <span id="service_duration"></span> min | 
                        <strong>Precio:</strong> <span id="service_price"></span>
                    </p>
                    <div id="emergency_service_notice" class="mt-2 p-2 bg-red-100 border border-red-300 rounded text-sm text-red-800 hidden">
                        <i class="fas fa-exclamation-triangle mr-1"></i>
                        <strong>Servicio de Emergencia:</strong> Solo disponible en horarios de emergencia
                    </div>
                </div>
            </div>
            
            <!-- Horarios disponibles -->
            <div id="create_time_section" style="display:none;">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-clock mr-1"></i>Horario Disponible *
                </label>
                <div id="time_slots_container" class="grid grid-cols-4 gap-2">
                    <!-- Time slots will be loaded here -->
                </div>
                <p class="text-xs text-gray-500 mt-2" id="no_slots_message" style="display:none;">
                    <i class="fas fa-info-circle mr-1"></i>No hay horarios disponibles para esta fecha
                </p>
            </div>
            
            <!-- Notas -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-notes-medical mr-1"></i>Notas adicionales
                </label>
                <textarea id="create_notas" rows="3"
                          placeholder="Informaci&oacute;n adicional..."
                          class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"></textarea>
            </div>
            
            <input type="hidden" id="create_fecha" value="">
            <input type="hidden" id="create_especialista_id" value="<?= $currentSpecialistId ?? '' ?>">
            <input type="hidden" id="create_hora_inicio" value="">
        </form>
        
        <div class="p-6 bg-gray-50 border-t rounded-b-2xl sticky bottom-0">
            <div class="flex justify-end gap-3">
                <button onclick="closeCreateModal()" class="px-6 py-2.5 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
                    <i class="fas fa-times mr-2"></i>Cancelar
                </button>
                <button id="createModalSubmitBtn" onclick="submitCreateReservation()" class="px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition shadow-md hover:shadow-lg">
                    <i class="fas fa-check mr-2"></i>Crear Reservaci&oacute;n
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Event Modal -->
<div id="eventModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-2xl max-w-5xl max-h-[calc(100vh-2rem)] overflow-y-auto w-full transform transition-all">
        <div class="p-6 bg-gradient-to-r from-primary to-secondary rounded-t-2xl">
            <div class="flex justify-between items-center">
                <h3 class="text-xl font-bold text-white flex items-center" id="modal-title">
                    <i class="fas fa-calendar-check mr-3"></i>
                    <span>Detalles de la Cita</span>
                </h3>
                <button onclick="closeModal()" class="text-white hover:text-gray-200 transition">
                    <i class="fas fa-times text-2xl"></i>
                </button>
            </div>
        </div>
        <div class="p-6" id="modal-content">
            <!-- Content loaded dynamically -->
        </div>
        <div class="p-6" id="modal-edit-content" style="display:none;">
            <!-- Edit form loaded dynamically -->
        </div>
        <div class="p-6 bg-gray-50 border-t rounded-b-2xl" id="modal-footer-view">
            <div class="space-y-3">
                <p class="text-sm text-gray-500 text-center">
                    <i class="fas fa-info-circle mr-1"></i>
                    Haz clic en "Ver Detalle" para m&aacute;s informaci&oacute;n
                </p>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <!-- Confirmar: solo si está pendiente -->
                    <button onclick="confirmReservation()" id="modal-confirm-btn" class="px-4 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition shadow-md hover:shadow-lg flex items-center justify-center" style="display:none;">
                        <i class="fas fa-check-circle mr-2"></i>Confirmar
                    </button>
                    <!-- Reagendar: solo si está pendiente -->
                    <button onclick="toggleEditMode()" id="modal-reschedule-btn" class="px-4 py-2.5 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 transition shadow-md hover:shadow-lg flex items-center justify-center" style="display:none;">
                        <i class="fas fa-edit mr-2"></i>Reagendar
                    </button>
                    <!-- Completar: solo si está confirmada -->
                    <button onclick="completeReservation()" id="modal-complete-btn" class="px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition shadow-md hover:shadow-lg flex items-center justify-center" style="display:none;">
                        <i class="fas fa-check-double mr-2"></i>Completar
                    </button>
                    <!-- No Asistió: solo si está confirmada -->
                    <button onclick="noShowReservation()" id="modal-noshow-btn" class="px-4 py-2.5 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition shadow-md hover:shadow-lg flex items-center justify-center" style="display:none;">
                        <i class="fas fa-user-times mr-2"></i>No Asisti&oacute;
                    </button>
                    <!-- Cancelar: si está pendiente o confirmada -->
                    <button onclick="cancelReservation()" id="modal-cancel-btn" class="px-4 py-2.5 bg-red-600 text-white rounded-lg hover:bg-red-700 transition shadow-md hover:shadow-lg flex items-center justify-center" style="display:none;">
                        <i class="fas fa-times-circle mr-2"></i>Cancelar
                    </button>
                    <!-- Ver en Pagos: solo si está completada -->
                    <a href="<?= url('/pagos') ?>" id="modal-payments-btn" class="px-4 py-2.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition shadow-md hover:shadow-lg flex items-center justify-center" style="display:none;">
                        <i class="fas fa-money-bill-wave mr-2"></i>Ver en Pagos
                    </a>
                    <!-- Ver Detalle: siempre visible -->
                    <a href="#" id="modal-view-link" class="px-4 py-2.5 bg-primary text-white rounded-lg hover:bg-secondary transition shadow-md hover:shadow-lg flex items-center justify-center">
                        <i class="fas fa-eye mr-2"></i>Ver Detalle
                    </a>
                </div>
            </div>
        </div>
        <div class="p-6 bg-gray-50 border-t rounded-b-2xl" id="modal-footer-edit" style="display:none;">
            <div class="flex justify-end gap-3">
                <button onclick="cancelEdit()" class="px-6 py-2.5 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
                    <i class="fas fa-times mr-2"></i>Cancelar
                </button>
                <button onclick="saveReschedule()" class="px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition shadow-md hover:shadow-lg">
                    <i class="fas fa-save mr-2"></i>Guardar Cambios
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Variables globales
<?php if ($user['rol_id'] == ROLE_SPECIALIST): ?>
// Crear mapeo de sucursales a colores personalizados
const sucursalColorMap = {};
<?php foreach ($branches as $branch): ?>
sucursalColorMap[<?= $branch['id'] ?>] = '<?= $branch['color'] ?? '#3B82F6' ?>';
<?php endforeach; ?>

// Función para convertir color hex a rgba con opacidad
function hexToRgba(hex, alpha) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
<?php endif; ?>

// Horarios de especialistas para businessHours
const horariosEspecialistas = <?= json_encode($horariosEspecialistas ?? []) ?>;
const horariosPorSucursal = <?= json_encode($branchSchedules ?? []) ?>;
const especialistaPorSucursal = <?= json_encode($specialistBranchMap ?? []) ?>;

// Función para convertir horarios a formato FullCalendar businessHours
function convertirHorariosABusinessHours(horarios) {
    if (!horarios || horarios.length === 0) {
        return undefined; // Sin restricciones
    }
    
    // Agrupar por día de la semana
    const horariosPorDia = {};
    horarios.forEach(h => {
        // Convertir dia_semana (1=Lunes...7=Domingo) a daysOfWeek (0=Domingo, 1=Lunes...6=Sábado)
        const diaSemana = parseInt(h.dia_semana, 10);
        const diaFC = diaSemana === 7 ? 0 : diaSemana;
        
        if (!horariosPorDia[diaFC]) {
            horariosPorDia[diaFC] = [];
        }
        horariosPorDia[diaFC].push({
            startTime: h.hora_inicio.substring(0, 5), // "09:00:00" -> "09:00"
            endTime: h.hora_fin.substring(0, 5)
        });
    });
    
    // Convertir a formato FullCalendar
    const businessHours = [];
    for (const dia in horariosPorDia) {
        horariosPorDia[dia].forEach(rango => {
            businessHours.push({
                daysOfWeek: [parseInt(dia)],
                startTime: rango.startTime,
                endTime: rango.endTime
            });
        });
    }
    
    return businessHours;
}

// Generar eventos de bloqueo visual para mostrar en el calendario
function generarEventosBloqueoVisual(fechaInicio, fechaFin, especialistaId) {
    const eventos = [];
    
    console.log('📅 Generando bloqueos visuales...');
    console.log('- Fecha inicio:', fechaInicio);
    console.log('- Fecha fin:', fechaFin);
    console.log('- Especialista ID:', especialistaId);
    console.log('- Horarios disponibles:', horariosEspecialistas);
    
    // Obtener horarios del especialista seleccionado
    let horarios = [];
    const sucursalId = document.getElementById('filter_sucursal')?.value || '';
    if (especialistaId && horariosEspecialistas[especialistaId]) {
        horarios = horariosEspecialistas[especialistaId];
        console.log('✓ Usando horarios del especialista', especialistaId);
    } else if (sucursalId && horariosPorSucursal[sucursalId]) {
        horarios = horariosPorSucursal[sucursalId];
        console.log('Usando horarios de la sucursal', sucursalId);
    } else if (horariosEspecialistas['current']) {
        horarios = horariosEspecialistas['current'];
        console.log('✓ Usando horarios current');
    }
    
    console.log('- Horarios a procesar:', horarios);
    
    if (!horarios || horarios.length === 0) {
        console.log('❌ No hay horarios para procesar');
        return eventos;
    }
    
    // Recorrer cada día en el rango visible
    const inicio = new Date(fechaInicio);
    const fin = new Date(fechaFin);
    
    for (let fecha = new Date(inicio); fecha <= fin; fecha.setDate(fecha.getDate() + 1)) {
        // Obtener día de la semana (1=Lunes...7=Domingo)
        const diaSemana = fecha.getDay() === 0 ? 7 : fecha.getDay();
        
        // Buscar horario de este día que tenga bloqueo activo
        const horarioDelDia = horarios.find(h => parseInt(h.dia_semana) === diaSemana);
        
        console.log(`- Día ${diaSemana} (${fecha.toISOString().split('T')[0]}):`, horarioDelDia);
        
        if (horarioDelDia && horarioDelDia.bloqueo_activo && 
            horarioDelDia.hora_inicio_bloqueo && horarioDelDia.hora_fin_bloqueo) {
            
            // Crear evento de bloqueo visual
            const fechaStr = fecha.toISOString().split('T')[0];
            const bloqueEvento = {
                id: 'bloqueo_' + fechaStr + '_' + diaSemana,
                start: fechaStr + 'T' + horarioDelDia.hora_inicio_bloqueo,
                end: fechaStr + 'T' + horarioDelDia.hora_fin_bloqueo,
                display: 'background',
                backgroundColor: 'rgba(220, 38, 38, 0.08)', // Rojo muy suave
                borderColor: 'rgba(220, 38, 38, 0.15)',
                editable: false,
                classNames: ['bloqueo-visual']
            };
            eventos.push(bloqueEvento);
            console.log('  ✅ Bloqueo creado:', bloqueEvento);
        } else if (horarioDelDia) {
            console.log('  ⚠️ Día tiene horario pero no tiene bloqueo activo o no tiene horas configuradas');
        }
    }
    
    console.log('📊 Total bloqueos generados:', eventos.length);
    return eventos;
}

// Obtener businessHours inicial
function getBusinessHours() {
    const especialistaId = document.getElementById('filter_especialista')?.value;
    const sucursalId = document.getElementById('filter_sucursal')?.value || '';
    
    if (especialistaId && horariosEspecialistas[especialistaId]) {
        return convertirHorariosABusinessHours(horariosEspecialistas[especialistaId]);
    } else if (sucursalId && horariosPorSucursal[sucursalId]) {
        return convertirHorariosABusinessHours(horariosPorSucursal[sucursalId]);
    } else if (horariosEspecialistas['current']) {
        // Para especialistas que ven su propio calendario
        return convertirHorariosABusinessHours(horariosEspecialistas['current']);
    }
    
    return undefined; // Sin restricciones si no hay horarios
}

document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');
    
    window.calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'timeGridWeek',
        locale: 'es',
        height: 'auto',
        expandRows: true,
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
        },
        buttonText: {
            today: 'Hoy',
            month: 'Mes',
            week: 'Semana',
            day: 'Dia',
            list: 'Lista'
        },
        buttonIcons: {
            prev: 'chevron-left',
            next: 'chevron-right'
        },
        events: function(info, successCallback, failureCallback) {
            const specialistId = document.getElementById('filter_especialista')?.value || '';
            const branchId = document.getElementById('filter_sucursal')?.value || '';
            
            let url = '<?= url('/calendario/eventos') ?>?start=' + info.startStr + '&end=' + info.endStr;
            if (specialistId) url += '&especialista_id=' + specialistId;
            if (branchId) url += '&sucursal_id=' + branchId;
            
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    // Agregar eventos de bloqueo visual
                    const bloqueosVisuales = generarEventosBloqueoVisual(info.start, info.end, specialistId);
                    const todosLosEventos = [...data, ...bloqueosVisuales];
                    successCallback(todosLosEventos);
                })
                .catch(error => {
                    console.error('Error loading events:', error);
                    failureCallback(error);
                });
        },
        eventClick: function(info) {
            showEventModal(info.event);
        },
        dateClick: function(info) {
            // Solo permitir clicks en fechas futuras o hoy
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            // Extraer fecha y hora si viene en formato ISO
            const fechaSoloDate = info.dateStr.split('T')[0];
            // Crear fecha en hora local para evitar problemas de zona horaria
            const partesFecha = fechaSoloDate.split('-');
            const clickedDate = new Date(partesFecha[0], partesFecha[1] - 1, partesFecha[2]);
            clickedDate.setHours(0, 0, 0, 0);
            
            if (clickedDate >= today) {
                // Extraer hora si viene en el dateStr (vista semanal/día)
                let horaSeleccionada = null;
                if (info.dateStr.includes('T')) {
                    const partes = info.dateStr.split('T');
                    if (partes[1]) {
                        horaSeleccionada = partes[1].substring(0, 5); // "09:00"
                    }
                }
                openActionModal(info.dateStr, horaSeleccionada);
            }
        },
        eventDidMount: function(info) {
            // Add tooltip with enhanced styling
            info.el.title = info.event.title;
            info.el.style.cursor = 'pointer';
            info.el.style.transition = 'all 0.2s';
            
            // Para eventos de tipo reservacion, mostrar información en dos líneas
            if (info.event.extendedProps.tipo === 'reservacion') {
                const titleEl = info.el.querySelector('.fc-event-title');
                if (titleEl) {
                    const servicio = info.event.extendedProps.servicio || info.event.title;
                    const cliente = info.event.extendedProps.cliente || '';
                    const precio = info.event.extendedProps.precio || '';
                    
                    titleEl.innerHTML = `
                        <div style="line-height: 1.2;">
                            <div style="font-weight: 500;">${servicio}</div>
                            <div style="font-size: 0.85em; margin-top: 2px;">${cliente} ${precio}</div>
                        </div>
                    `;
                }
            }
            
            // Marcar visualmente las citas extraordinarias
            if (info.event.extendedProps.es_extraordinaria) {
                info.el.style.borderLeft = '4px solid #ff6b00';
                info.el.style.borderRight = '4px solid #ff6b00';
                info.el.style.opacity = '0.9';
                
                // Agregar ícono de reloj en el título
                const titleEl = info.el.querySelector('.fc-event-title');
                if (titleEl) {
                    const icon = document.createElement('i');
                    icon.className = 'fas fa-user-clock mr-1';
                    icon.style.color = '#ff6b00';
                    const firstDiv = titleEl.querySelector('div > div:first-child');
                    if (firstDiv) {
                        firstDiv.prepend(icon);
                    } else {
                        titleEl.prepend(icon);
                    }
                }
            }
            
            // Add hover effect
            info.el.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.02)';
                this.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
            });
            info.el.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
                this.style.boxShadow = 'none';
            });
            
            <?php if ($user['rol_id'] == ROLE_SPECIALIST): ?>
            // Colorear la celda del día cuando se monta un evento
            const fecha = info.event.start;
            if (fecha && info.event.extendedProps.sucursal_id) {
                // Verificar si hay filtro de sucursal activo
                const filtroSucursal = document.getElementById('filter_sucursal')?.value || '';
                
                // Si hay filtro y el evento no es de esa sucursal, no colorear
                if (filtroSucursal && info.event.extendedProps.sucursal_id != filtroSucursal) {
                    return;
                }
                
                const year = fecha.getFullYear();
                const month = String(fecha.getMonth() + 1).padStart(2, '0');
                const day = String(fecha.getDate()).padStart(2, '0');
                const fechaStr = `${year}-${month}-${day}`;
                
                const sucursalId = info.event.extendedProps.sucursal_id;
                const colorHex = sucursalColorMap[sucursalId] || '#3B82F6';
                
                // Detectar si es hoy
                const hoy = new Date();
                const hoyStr = `${hoy.getFullYear()}-${String(hoy.getMonth() + 1).padStart(2, '0')}-${String(hoy.getDate()).padStart(2, '0')}`;
                const esHoy = fechaStr === hoyStr;
                
                // Usar opacidad diferente para hoy vs otros días
                const opacidad = esHoy ? 0.45 : 0.25;
                const color = hexToRgba(colorHex, opacidad);
                
                // Buscar la celda correspondiente
                setTimeout(() => {
                    const celda = document.querySelector(`.fc-day[data-date="${fechaStr}"]`);
                    if (celda) {
                        celda.style.backgroundColor = color;
                        celda.style.transition = 'background-color 0.3s ease';
                    }
                }, 10);
            }
            <?php endif; ?>
        },
        slotMinTime: '07:00:00',
        slotMaxTime: '21:00:00',
        slotMinHeight: 50, // Aumentar altura de cada slot de 30 minutos para mejor visibilidad
        slotEventOverlap: true, // Permitir que eventos se solapen visualmente
        eventMinWidth: 120, // Ancho mínimo de eventos para que se vea el texto
        allDaySlot: false,
        nowIndicator: true,
        editable: false,
        selectable: true,
        selectMirror: true,
        dayMaxEvents: 3,
        moreLinkText: 'más',
        businessHours: getBusinessHours(),
        eventTimeFormat: {
            hour: '2-digit',
            minute: '2-digit',
            meridiem: false
        },
        slotLabelFormat: {
            hour: '2-digit',
            minute: '2-digit',
            meridiem: false
        },
        slotLabelInterval: '00:15:00', // Mostrar etiquetas cada 15 minutos
        views: {
            timeGridWeek: {
                slotDuration: '00:15:00'
            },
            timeGridDay: {
                slotDuration: '00:15:00'
            }
        }
    });
    
    calendar.render();
});

function filterCalendar(source = '') {
    const branchSelect = document.getElementById('filter_sucursal');
    const specialistSelect = document.getElementById('filter_especialista');

    if (branchSelect && specialistSelect) {
        const branchId = branchSelect.value;

        Array.from(specialistSelect.options).forEach(option => {
            if (!option.value) return;
            const belongsToBranch = !branchId || option.dataset.branchId === branchId;
            option.hidden = !belongsToBranch;
            option.disabled = !belongsToBranch;
        });

        const selectedOption = specialistSelect.selectedOptions[0];
        if (source === 'branch' && branchId && selectedOption?.value && selectedOption.dataset.branchId !== branchId) {
            specialistSelect.value = '';
        }
    }

    <?php if ($user['rol_id'] == ROLE_SPECIALIST): ?>
    // Limpiar colores de fondo antes de recargar eventos
    document.querySelectorAll('.fc-day').forEach(celda => {
        celda.style.backgroundColor = '';
    });
    <?php endif; ?>
    
    // Actualizar businessHours según el especialista seleccionado
    const newBusinessHours = getBusinessHours();
    if (window.calendar) {
        window.calendar.setOption('businessHours', newBusinessHours);
    }
    
    window.calendar.refetchEvents();
}

// Función para mostrar/ocultar el panel de colores
function toggleColorPicker() {
    const panel = document.getElementById('colorPickerPanel');
    const icon = document.getElementById('colorPickerIcon');
    
    if (panel.classList.contains('hidden')) {
        panel.classList.remove('hidden');
        icon.classList.remove('fa-chevron-down');
        icon.classList.add('fa-chevron-up');
    } else {
        panel.classList.add('hidden');
        icon.classList.remove('fa-chevron-up');
        icon.classList.add('fa-chevron-down');
    }
}

// Función para actualizar el color de una sucursal
async function updateBranchColor(branchId, color) {
    try {
        const response = await fetch('<?= url('/sucursales/actualizar-color') ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${branchId}&color=${encodeURIComponent(color)}`
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Actualizar el mapa de colores
            if (typeof sucursalColorMap !== 'undefined') {
                sucursalColorMap[branchId] = color;
            }
            
            // Recargar eventos para reflejar el nuevo color
            if (window.calendar) {
                window.calendar.refetchEvents();
            }
            
            // Mostrar mensaje de éxito
            showToast('Color actualizado correctamente', 'success');
        } else {
            showToast(result.message || 'Error al actualizar el color', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Error al actualizar el color', 'error');
    }
}

// Función auxiliar para mostrar mensajes toast
function showToast(message, type = 'info') {
    const colors = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        info: 'bg-blue-500'
    };
    
    const toast = document.createElement('div');
    toast.className = `fixed bottom-4 right-4 ${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 transition-opacity duration-300`;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

let currentEvent = null;
let editAvailabilityRequestId = 0;

function showEventModal(event) {
    currentEvent = event;
    const modal = document.getElementById('eventModal');
    const props = event.extendedProps;
    
    // Verificar si es un bloqueo o una reservación
    if (props.tipo === 'bloqueo') {
        showBlockDetails(event);
        return;
    }
    
    const startDate = new Date(event.start);
    const endDate = new Date(event.end);
    const dateStr = startDate.toLocaleDateString('es-MX', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    const timeStr = startDate.toLocaleTimeString('es-MX', { 
        hour: '2-digit', 
        minute: '2-digit' 
    }) + ' - ' + endDate.toLocaleTimeString('es-MX', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    // Asegurarse de estar en modo vista
    document.getElementById('modal-content').style.display = 'block';
    document.getElementById('modal-edit-content').style.display = 'none';
    document.getElementById('modal-footer-view').style.display = 'block';
    document.getElementById('modal-footer-edit').style.display = 'none';
    
    // Mostrar/ocultar botones según estado
    const confirmBtn = document.getElementById('modal-confirm-btn');
    const rescheduleBtn = document.getElementById('modal-reschedule-btn');
    const completeBtn = document.getElementById('modal-complete-btn');
    const noShowBtn = document.getElementById('modal-noshow-btn');
    const cancelBtn = document.getElementById('modal-cancel-btn');
    const paymentsBtn = document.getElementById('modal-payments-btn');
    
    // Ocultar todos primero
    confirmBtn.style.display = 'none';
    rescheduleBtn.style.display = 'none';
    completeBtn.style.display = 'none';
    noShowBtn.style.display = 'none';
    cancelBtn.style.display = 'none';
    paymentsBtn.style.display = 'none';
    
    // Lógica según estado
    switch(props.estado) {
        case 'pendiente':
            // Pendiente: Confirmar, Reagendar, Cancelar
            confirmBtn.style.display = 'block';
            rescheduleBtn.style.display = 'block';
            cancelBtn.style.display = 'block';
            break;
            
        case 'confirmada':
            // Confirmada: Completar, No Asistió, Cancelar (NO reagendar)
            completeBtn.style.display = 'block';
            noShowBtn.style.display = 'block';
            cancelBtn.style.display = 'block';
            break;
            
        case 'completada':
            // Completada: mostrar botón de Ver en Pagos
            paymentsBtn.style.display = 'block';
            break;
            
        case 'cancelada':
        case 'no_asistio':
            // Estados finales: solo ver detalle (todos los botones ocultos)
            break;
    }
    
    document.getElementById('modal-content').innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div class="flex items-start p-3 bg-blue-50 rounded-lg md:col-span-2 lg:col-span-3">
                <i class="fas fa-calendar text-blue-600 mt-1 mr-3"></i>
                <div>
                    <p class="text-sm font-medium text-gray-700">Fecha y Hora</p>
                    <p class="text-sm text-gray-900">${dateStr}</p>
                    <p class="text-sm text-blue-600 font-semibold">${timeStr}</p>
                </div>
            </div>
            
            ${props.es_extraordinaria ? `
            <div class="p-3 bg-orange-100 border-2 border-orange-400 rounded-lg md:col-span-2 lg:col-span-3">
                <div class="flex items-center">
                    <i class="fas fa-user-clock text-orange-600 mr-2"></i>
                    <div>
                        <p class="text-sm font-bold text-orange-800">CITA EXTRAORDINARIA</p>
                        <p class="text-xs text-orange-700">Esta cita se creó sin validar disponibilidad de horarios</p>
                    </div>
                </div>
            </div>
            ` : ''}
            
            <div class="contents">
                <div class="p-3 bg-gray-50 rounded-lg">
                    <p class="text-xs text-gray-500 mb-1"><i class="fas fa-barcode mr-1"></i>Código</p>
                    <p class="text-sm font-semibold text-gray-900">${props.codigo}</p>
                </div>
                <div class="p-3 bg-gray-50 rounded-lg">
                    <p class="text-xs text-gray-500 mb-1"><i class="fas fa-flag mr-1"></i>Estado</p>
                    <span class="inline-block px-2 py-1 rounded-full text-xs font-medium ${getStatusClass(props.estado)}">
                        ${props.estado.charAt(0).toUpperCase() + props.estado.slice(1)}
                    </span>
                </div>
            </div>
            
            <div class="p-3 bg-green-50 rounded-lg">
                <p class="text-xs text-gray-500 mb-1"><i class="fas fa-user mr-1"></i>Cliente</p>
                <p class="text-sm font-semibold text-gray-900">${props.cliente}</p>
                <p class="text-xs text-gray-600 mt-1"><i class="fas fa-phone mr-1"></i>${props.telefono || 'Sin número'}</p>
            </div>
            
            <div class="p-3 bg-purple-50 rounded-lg">
                <p class="text-xs text-gray-500 mb-1"><i class="fas fa-user-md mr-1"></i>Especialista</p>
                <p class="text-sm font-semibold text-gray-900">${props.especialista}</p>
            </div>
            
            <div class="contents">
                <div class="p-3 bg-indigo-50 rounded-lg">
                    <p class="text-xs text-gray-500 mb-1"><i class="fas fa-concierge-bell mr-1"></i>Servicio</p>
                    <p class="text-sm font-semibold text-gray-900">${props.servicio}</p>
                </div>
                <div class="p-3 bg-emerald-50 rounded-lg">
                    <p class="text-xs text-gray-500 mb-1"><i class="fas fa-dollar-sign mr-1"></i>Precio</p>
                    <p class="text-sm font-semibold text-emerald-700">${props.precio}</p>
                </div>
            </div>
            
            ${props.estado === 'confirmada' ? `
            <div class="p-4 bg-yellow-50 border-2 border-yellow-200 rounded-lg md:col-span-2 lg:col-span-3">
                <p class="text-sm text-gray-700 mb-2">
                    <i class="fas fa-credit-card mr-2"></i><strong>M&eacute;todo de Pago *</strong>
                </p>
                <p class="text-xs text-gray-600 mb-3 italic">
                    Agregar método de pago marcará como completada la cita
                </p>
                <select id="quick-payment-method" onchange="quickCompleteWithPayment()"
                        class="w-full px-4 py-2.5 border-2 border-yellow-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 bg-white">
                    <option value="">-- Seleccione un método --</option>
                    <option value="efectivo">Efectivo</option>
                    <option value="tarjeta">Tarjeta</option>
                    <option value="transferencia">Transferencia</option>
                    <option value="paypal">PayPal</option>
                    <option value="cortesia">Cortes&iacute;a</option>
                </select>
            </div>
            ` : ''}
        </div>
    `;
    document.getElementById('modal-view-link').href = '<?= url('/reservaciones/ver') ?>?id=' + event.id;
    
    modal.classList.remove('hidden');
}

function showBlockDetails(event) {
    const modal = document.getElementById('eventModal');
    const props = event.extendedProps;
    
    const startDate = new Date(event.start);
    const endDate = new Date(event.end);
    const dateStr = startDate.toLocaleDateString('es-MX', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    const timeStr = startDate.toLocaleTimeString('es-MX', { 
        hour: '2-digit', 
        minute: '2-digit' 
    }) + ' - ' + endDate.toLocaleTimeString('es-MX', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    // Asegurarse de estar en modo vista
    document.getElementById('modal-content').style.display = 'block';
    document.getElementById('modal-edit-content').style.display = 'none';
    document.getElementById('modal-footer-view').style.display = 'none'; // Ocultar footer de reservaciones
    document.getElementById('modal-footer-edit').style.display = 'none';
    
    const tipoLabels = {
        'vacaciones': { icon: '🌴', label: 'Vacaciones', color: 'blue' },
        'pausa': { icon: '☕', label: 'Pausa/Descanso', color: 'yellow' },
        'personal': { icon: '👤', label: 'Asunto Personal', color: 'purple' },
        'puntual': { icon: '🔒', label: 'Bloqueo Puntual', color: 'red' },
        'cirugia': { icon: '⚕️', label: 'Cirugía', color: 'purple' },
        'otro': { icon: '⛔', label: 'No Disponible', color: 'gray' }
    };
    
    const tipoInfo = tipoLabels[props.tipo_bloqueo] || tipoLabels['otro'];
    
    document.getElementById('modal-content').innerHTML = `
        <div class="space-y-4">
            <div class="flex items-start p-4 bg-red-50 border-2 border-red-200 rounded-lg">
                <div class="text-4xl mr-4">${tipoInfo.icon}</div>
                <div class="flex-1">
                    <p class="text-lg font-bold text-red-800">${tipoInfo.label}</p>
                    <p class="text-sm text-red-600">Horario bloqueado y no disponible para reservaciones</p>
                </div>
            </div>
            
            <div class="flex items-start p-3 bg-blue-50 rounded-lg">
                <i class="fas fa-calendar text-blue-600 mt-1 mr-3"></i>
                <div>
                    <p class="text-sm font-medium text-gray-700">Fecha y Hora</p>
                    <p class="text-sm text-gray-900">${dateStr}</p>
                    <p class="text-sm text-blue-600 font-semibold">${timeStr}</p>
                </div>
            </div>
            
            <div class="p-3 bg-purple-50 rounded-lg">
                <p class="text-xs text-gray-500 mb-1"><i class="fas fa-user-md mr-1"></i>Especialista</p>
                <p class="text-sm font-semibold text-gray-900">${props.especialista}</p>
            </div>
            
            <div class="p-3 bg-gray-50 rounded-lg">
                <p class="text-xs text-gray-500 mb-1"><i class="fas fa-building mr-1"></i>Sucursal</p>
                <p class="text-sm font-semibold text-gray-900">${props.sucursal}</p>
            </div>
            
            ${props.motivo ? `
            <div class="p-3 bg-yellow-50 rounded-lg">
                <p class="text-xs text-gray-500 mb-1"><i class="fas fa-comment mr-1"></i>Motivo</p>
                <p class="text-sm text-gray-900">${props.motivo}</p>
            </div>
            ` : ''}
            
            <div class="p-4 bg-gray-100 rounded-lg border-t-4 border-red-500">
                <div class="flex items-center justify-between">
                    <p class="text-sm text-gray-700"><i class="fas fa-info-circle mr-2"></i>ID del Bloqueo</p>
                    <p class="text-sm font-mono font-semibold text-gray-900">#${props.bloqueo_id}</p>
                </div>
            </div>
        </div>
        
        <div class="mt-6 p-4 bg-gray-50 border-t rounded-b-lg">
            <div class="flex justify-center gap-3">
                <?php if ($user['rol_id'] == ROLE_SPECIALIST): ?>
                <button onclick="deleteBlock(${props.bloqueo_id})" class="px-6 py-2.5 bg-red-600 text-white rounded-lg hover:bg-red-700 transition shadow-md hover:shadow-lg">
                    <i class="fas fa-trash mr-2"></i>Eliminar Bloqueo
                </button>
                <?php endif; ?>
                <button onclick="closeModal()" class="px-6 py-2.5 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition shadow-md hover:shadow-lg">
                    <i class="fas fa-times mr-2"></i>Cerrar
                </button>
            </div>
        </div>
    `;
    
    modal.classList.remove('hidden');
}

function closeModal() {
    document.getElementById('eventModal').classList.add('hidden');
    currentEvent = null;
}

function toggleEditMode() {
    if (!currentEvent) return;
    
    const startDate = new Date(currentEvent.start);
    const props = currentEvent.extendedProps;
    const fechaStr = startDate.toISOString().split('T')[0];
    const horaInicio = startDate.toTimeString().substring(0, 5);
    
    document.getElementById('modal-edit-content').innerHTML = `
        <div class="space-y-4">
            <div class="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <p class="text-sm font-semibold text-blue-800 mb-2">
                    <i class="fas fa-info-circle mr-2"></i>Reagendamiento de Cita
                </p>
                <p class="text-xs text-gray-600">
                    Selecciona nueva fecha y hora para la cita. El sistema verificará la disponibilidad automáticamente.
                </p>
            </div>
            
            <div class="grid grid-cols-2 gap-4 p-3 bg-gray-50 rounded-lg">
                <div>
                    <p class="text-xs text-gray-500 mb-1"><i class="fas fa-barcode mr-1"></i>Código</p>
                    <p class="text-sm font-semibold text-gray-900">${props.codigo}</p>
                </div>
                <div>
                    <p class="text-xs text-gray-500 mb-1"><i class="fas fa-concierge-bell mr-1"></i>Servicio</p>
                    <p class="text-sm font-semibold text-gray-900">${props.servicio}</p>
                </div>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-calendar-day mr-1 text-primary"></i>Nueva Fecha
                </label>
                <input type="date" id="edit-fecha" value="${fechaStr}" 
                       onchange="loadAvailableTimesForEdit()"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
            </div>
            
            <div id="edit-time-container">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-clock mr-1 text-primary"></i>Nueva Hora
                </label>
                <div class="text-center py-4 text-gray-500">
                    <i class="fas fa-spinner fa-spin mr-2"></i>Cargando horarios disponibles...
                </div>
            </div>
            
            <input type="hidden" id="edit-reservacion-id" value="${currentEvent.id}">
            <input type="hidden" id="edit-especialista-id" value="${props.especialista_id || ''}">
            <input type="hidden" id="edit-servicio-id" value="${props.servicio_id || ''}">
            <input type="hidden" id="edit-sucursal-id" value="${props.sucursal_id || ''}">
        </div>
    `;
    
    // Cambiar a modo edición
    document.getElementById('modal-content').style.display = 'none';
    document.getElementById('modal-edit-content').style.display = 'block';
    document.getElementById('modal-footer-view').style.display = 'none';
    document.getElementById('modal-footer-edit').style.display = 'block';
    
    // Cargar horarios disponibles para la fecha actual
    loadAvailableTimesForEdit();
}

function cancelEdit() {
    editAvailabilityRequestId++;
    document.getElementById('modal-content').style.display = 'block';
    document.getElementById('modal-edit-content').style.display = 'none';
    document.getElementById('modal-footer-view').style.display = 'block';
    document.getElementById('modal-footer-edit').style.display = 'none';
}

async function loadAvailableTimesForEdit() {
    const fecha = document.getElementById('edit-fecha').value;
    const especialistaId = document.getElementById('edit-especialista-id').value;
    const servicioId = document.getElementById('edit-servicio-id').value;
    const sucursalId = document.getElementById('edit-sucursal-id').value;
    const reservacionId = document.getElementById('edit-reservacion-id').value;
    
    if (!fecha || !especialistaId || !servicioId || !sucursalId) return;
    const requestId = ++editAvailabilityRequestId;
    
    const container = document.getElementById('edit-time-container');
    container.innerHTML = `
        <label class="block text-sm font-medium text-gray-700 mb-2">
            <i class="fas fa-clock mr-1 text-primary"></i>Nueva Hora
        </label>
        <div class="text-center py-4 text-gray-500">
            <i class="fas fa-spinner fa-spin mr-2"></i>Cargando horarios disponibles...
        </div>
    `;
    
    try {
        const response = await fetch(`<?= BASE_URL ?>/api/disponibilidad?especialista_id=${especialistaId}&servicio_id=${servicioId}&fecha=${fecha}&sucursal_id=${sucursalId}&excluir_reservacion=${reservacionId}`);
        const data = await readJsonResponse(response);
        if (requestId !== editAvailabilityRequestId) return;
        
        if (data.slots && data.slots.length > 0) {
            let slotsHTML = `
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-clock mr-1 text-primary"></i>Nueva Hora
                </label>
                <div class="grid grid-cols-4 gap-2 max-h-64 overflow-y-auto p-2 border border-gray-200 rounded-lg">
            `;
            
            data.slots.forEach(slot => {
                const time = slot.hora_inicio.substring(0, 5);
                slotsHTML += `
                    <label class="relative cursor-pointer">
                        <input type="radio" name="edit-hora" value="${slot.hora_inicio}" class="peer sr-only">
                        <div class="p-2 border-2 rounded-lg text-center text-sm peer-checked:border-primary peer-checked:bg-blue-50 hover:border-gray-400 transition">
                            ${time}
                        </div>
                    </label>
                `;
            });
            
            slotsHTML += '</div>';
            container.innerHTML = slotsHTML;
        } else {
            container.innerHTML = `
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-clock mr-1 text-primary"></i>Nueva Hora
                </label>
                <div class="text-center py-4 text-orange-600 bg-orange-50 rounded-lg">
                    <i class="fas fa-exclamation-triangle mr-2"></i>${data.message || 'No hay horarios disponibles para esta fecha.'}
                </div>
            `;
        }
    } catch (error) {
        if (requestId !== editAvailabilityRequestId) return;
        console.error('Error al cargar horarios:', error);
        container.innerHTML = `
            <label class="block text-sm font-medium text-gray-700 mb-2">
                <i class="fas fa-clock mr-1 text-primary"></i>Nueva Hora
            </label>
            <div class="text-center py-4 text-red-600 bg-red-50 rounded-lg">
                <i class="fas fa-times-circle mr-2"></i>${error.message || 'Error al cargar horarios.'}
            </div>
        `;
    }
}

async function saveReschedule() {
    const reservacionId = document.getElementById('edit-reservacion-id').value;
    const nuevaFecha = document.getElementById('edit-fecha').value;
    const nuevaHora = document.querySelector('input[name="edit-hora"]:checked')?.value;
    
    if (!nuevaFecha || !nuevaHora) {
        alert('Por favor selecciona una fecha y hora');
        return;
    }
    
    try {
        const response = await fetch(`<?= BASE_URL ?>/reservaciones/reagendar`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${reservacionId}&fecha_cita=${nuevaFecha}&hora_inicio=${nuevaHora}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Cita reagendada exitosamente');
            closeModal();
            // Recargar eventos del calendario
            window.calendar.refetchEvents();
        } else {
            alert('Error al reagendar: ' + (data.message || 'Error desconocido'));
        }
    } catch (error) {
        console.error('Error al guardar:', error);
        alert('Error al guardar los cambios');
    }
}

function getStatusClass(status) {
    const classes = {
        'pendiente': 'bg-yellow-100 text-yellow-800 border border-yellow-200',
        'confirmada': 'bg-green-100 text-green-800 border border-green-200',
        'en_progreso': 'bg-blue-100 text-blue-800 border border-blue-200',
        'completada': 'bg-gray-100 text-gray-800 border border-gray-200',
        'cancelada': 'bg-red-100 text-red-800 border border-red-200',
        'no_asistio': 'bg-orange-100 text-orange-800 border border-orange-200'
    };
    return classes[status] || 'bg-gray-100 text-gray-800';
}

// Confirmar reservación
async function confirmReservation() {
    if (!currentEvent) return;
    
    if (!confirm('¿Está seguro de confirmar esta cita?')) {
        return;
    }
    
    try {
        const response = await fetch('<?= BASE_URL ?>/reservaciones/confirmar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${currentEvent.id}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Cita confirmada exitosamente');
            closeModal();
            window.calendar.refetchEvents();
        } else {
            alert('Error: ' + (data.message || 'No se pudo confirmar la cita'));
        }
    } catch (error) {
        console.error('Error al confirmar:', error);
        alert('Error al confirmar la cita');
    }
}

// Cancelar reservación
async function cancelReservation() {
    if (!currentEvent) return;
    
    const motivo = prompt('¿Por qué desea cancelar esta cita?\n(Opcional - presione Aceptar para continuar)');
    
    if (motivo === null) {
        // Usuario presionó Cancelar
        return;
    }
    
    if (!confirm('¿Está seguro de cancelar esta cita?')) {
        return;
    }
    
    try {
        const formData = new URLSearchParams();
        formData.append('id', currentEvent.id);
        if (motivo && motivo.trim()) {
            formData.append('motivo', motivo.trim());
        }
        
        const response = await fetch('<?= BASE_URL ?>/reservaciones/cancelar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Cita cancelada exitosamente');
            closeModal();
            window.calendar.refetchEvents();
        } else {
            alert('Error: ' + (data.message || 'No se pudo cancelar la cita'));
        }
    } catch (error) {
        console.error('Error al cancelar:', error);
        alert('Error al cancelar la cita');
    }
}

// Completar reservación
async function completeReservation() {
    if (!currentEvent) return;
    
    if (!confirm('¿Marcar esta cita como completada?')) {
        return;
    }
    
    try {
        const response = await fetch('<?= BASE_URL ?>/reservaciones/completar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${currentEvent.id}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Cita marcada como completada');
            closeModal();
            window.calendar.refetchEvents();
        } else {
            alert('Error: ' + (data.message || 'No se pudo completar la cita'));
        }
    } catch (error) {
        console.error('Error al completar:', error);
        alert('Error al completar la cita');
    }
}

// Completar rápido con método de pago
async function quickCompleteWithPayment() {
    if (!currentEvent) return;
    
    const paymentMethod = document.getElementById('quick-payment-method').value;
    
    if (!paymentMethod) {
        alert('Por favor seleccione un método de pago');
        return;
    }
    
    // Mapeo de nombres para mostrar
    const paymentNames = {
        'efectivo': 'Efectivo',
        'tarjeta': 'Tarjeta',
        'transferencia': 'Transferencia',
        'paypal': 'PayPal',
        'cortesia': 'Cortesía'
    };
    
    if (!confirm(`¿Completar cita con pago en ${paymentNames[paymentMethod]}?`)) {
        // Resetear selector si cancela
        document.getElementById('quick-payment-method').value = '';
        return;
    }
    
    try {
        const response = await fetch('<?= BASE_URL ?>/reservaciones/completar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${currentEvent.id}&metodo_pago=${encodeURIComponent(paymentMethod)}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('¡Cita completada exitosamente con pago registrado!');
            closeModal();
            window.calendar.refetchEvents();
        } else {
            alert('Error: ' + (data.message || 'No se pudo completar la cita'));
            // Resetear selector en caso de error
            document.getElementById('quick-payment-method').value = '';
        }
    } catch (error) {
        console.error('Error al completar con pago:', error);
        alert('Error al completar la cita');
        // Resetear selector en caso de error
        document.getElementById('quick-payment-method').value = '';
    }
}

// Marcar como no asistió
async function noShowReservation() {
    if (!currentEvent) return;
    
    if (!confirm('¿Marcar que el cliente NO asistió a esta cita?')) {
        return;
    }
    
    try {
        const response = await fetch('<?= BASE_URL ?>/reservaciones/no-asistio', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${currentEvent.id}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Marcado como no asistió');
            closeModal();
            window.calendar.refetchEvents();
        } else {
            alert('Error: ' + (data.message || 'No se pudo marcar como no asistió'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al marcar como no asistió');
    }
}

// Eliminar bloqueo de horario
async function deleteBlock(blockId) {
    if (!blockId) return;
    
    if (!confirm('¿Está seguro de eliminar este bloqueo de horario?')) {
        return;
    }
    
    try {
        const response = await fetch('<?= BASE_URL ?>/calendario/eliminar-bloqueo', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `bloqueo_id=${blockId}`
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Bloqueo eliminado exitosamente');
            closeModal();
            window.calendar.refetchEvents();
        } else {
            alert('Error: ' + (data.message || 'No se pudo eliminar el bloqueo'));
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al eliminar el bloqueo');
    }
}

// Close modal on overlay click
document.getElementById('eventModal')?.addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

document.getElementById('createModal')?.addEventListener('click', function(e) {
    if (e.target === this) closeCreateModal();
});

document.getElementById('actionModal')?.addEventListener('click', function(e) {
    if (e.target === this) closeActionModal();
});

document.getElementById('blockModal')?.addEventListener('click', function(e) {
    if (e.target === this) closeBlockModal();
});

// Close modal on ESC key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeModal();
        closeCreateModal();
        closeActionModal();
        closeBlockModal();
    }
});

// ============= FUNCIONES PARA MODAL DE ACCIONES =============

// Variables globales para almacenar fecha y hora seleccionadas
let selectedDateStr = null;
let selectedHoraStr = null;

// Variable global para indicar si estamos en modo cita extraordinaria
let esConsultaExtraordinaria = false;

function openActionModal(dateStr, horaSeleccionada = null) {
    const modal = document.getElementById('actionModal');
    const dateDisplay = document.getElementById('action-date-display');
    
    // Guardar fecha y hora seleccionadas
    selectedDateStr = dateStr;
    selectedHoraStr = horaSeleccionada;
    
    // Extraer solo la fecha (YYYY-MM-DD) del dateStr
    const fechaSoloDate = dateStr.split('T')[0];
    
    // Formatear fecha para display
    const fecha = new Date(fechaSoloDate + 'T00:00:00');
    const opciones = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const fechaFormateada = fecha.toLocaleDateString('es-MX', opciones);
    
    // Agregar hora al display si fue seleccionada
    let displayText = `Fecha seleccionada: ${fechaFormateada}`;
    if (horaSeleccionada) {
        displayText += ` a las ${horaSeleccionada}`;
    }
    
    dateDisplay.textContent = displayText;
    modal.classList.remove('hidden');
}

function closeActionModal() {
    const modal = document.getElementById('actionModal');
    modal.classList.add('hidden');
    selectedDateStr = null;
    selectedHoraStr = null;
}

function selectAgendarAction() {
    // Guardar valores ANTES de cerrar el modal (que los limpia)
    const fecha = selectedDateStr;
    const hora = selectedHoraStr;
    
    closeActionModal();
    
    // Abrir el modal de crear reservación con la fecha y hora guardadas
    if (fecha) {
        openCreateModal(fecha, hora);
    }
}

function selectBloquearAction() {
    // Guardar valores ANTES de cerrar el modal (que los limpia)
    const fecha = selectedDateStr;
    const hora = selectedHoraStr;
    
    closeActionModal();
    
    // Abrir el modal de bloqueo con la fecha y hora guardadas
    if (fecha) {
        openBlockModal(fecha, hora);
    }
}

// ============= FUNCIONES PARA MODAL DE BLOQUEO =============

function openBlockModal(dateStr, horaSeleccionada = null) {
    const modal = document.getElementById('blockModal');
    const dateDisplay = document.getElementById('block-date-display');
    const dateInput = document.getElementById('block_fecha');
    const horaInicioInput = document.getElementById('block_hora_inicio');
    const horaFinInput = document.getElementById('block_hora_fin');
    
    // Extraer solo la fecha (YYYY-MM-DD) del dateStr
    const fechaSoloDate = dateStr.split('T')[0];
    
    // Formatear fecha para display
    const fecha = new Date(fechaSoloDate + 'T00:00:00');
    const opciones = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const fechaFormateada = fecha.toLocaleDateString('es-MX', opciones);
    
    dateDisplay.textContent = `Bloquear: ${fechaFormateada}`;
    dateInput.value = fechaSoloDate;
    
    // Si viene hora pre-seleccionada, establecerla como inicio y calcular fin (+1 hora)
    if (horaSeleccionada) {
        horaInicioInput.value = horaSeleccionada;
        
        // Calcular hora fin (1 hora después)
        const [horas, minutos] = horaSeleccionada.split(':');
        const horaFin = new Date();
        horaFin.setHours(parseInt(horas) + 1, parseInt(minutos), 0, 0);
        const horaFinStr = horaFin.toTimeString().substring(0, 5);
        horaFinInput.value = horaFinStr;
    } else {
        // Valores por defecto
        horaInicioInput.value = '09:00';
        horaFinInput.value = '10:00';
    }
    
    // Resetear otros campos
    document.getElementById('block_tipo').value = 'puntual';
    document.getElementById('block_motivo').value = '';
    
    <?php if (!empty($branches) && count($branches) > 1): ?>
    document.getElementById('block_sucursal').value = '';
    <?php endif; ?>
    
    <?php if ($user['rol_id'] == ROLE_SPECIALIST): ?>
    // Si es especialista, determinar automáticamente la sucursal según el día
    const usuarioId = <?= $user['id'] ?>;
    document.getElementById('block_especialista_id').value = usuarioId;
    
    // Calcular el día de la semana (1=Lunes, 7=Domingo)
    const dayOfWeek = fecha.getDay();
    const diaSemana = dayOfWeek === 0 ? 7 : dayOfWeek;
    
    // Obtener la sucursal donde trabaja ese día
    fetch(`<?= BASE_URL ?>/api/especialista-sucursal-dia?usuario_id=${usuarioId}&dia_semana=${diaSemana}`)
        .then(response => response.json())
        .then(data => {
            if (data.sucursal_id) {
                document.getElementById('block_especialista_id').value = data.especialista_id;
                <?php if (!empty($branches) && count($branches) > 1): ?>
                document.getElementById('block_sucursal').value = data.sucursal_id;
                <?php endif; ?>
            } else {
                // No trabaja ese día, preguntar si quiere continuar
                if (!confirm('No tienes horarios configurados para este día. ¿Deseas bloquear de todas formas?')) {
                    closeBlockModal();
                    return;
                }
            }
        })
        .catch(error => {
            console.error('Error al obtener sucursal:', error);
        });
    <?php endif; ?>
    
    modal.classList.remove('hidden');
}

function closeBlockModal() {
    document.getElementById('blockModal').classList.add('hidden');
}

async function submitBlockSchedule() {
    const especialistaId = document.getElementById('block_especialista_id').value;
    const sucursalId = document.getElementById('block_sucursal')?.value || null;
    const fecha = document.getElementById('block_fecha').value;
    const horaInicio = document.getElementById('block_hora_inicio').value;
    const horaFin = document.getElementById('block_hora_fin').value;
    const tipo = document.getElementById('block_tipo').value;
    const motivo = document.getElementById('block_motivo').value;
    
    // Validaciones
    if (!fecha || !horaInicio || !horaFin || !tipo) {
        alert('Por favor complete todos los campos obligatorios');
        return;
    }
    
    if (horaInicio >= horaFin) {
        alert('La hora de inicio debe ser menor que la hora de fin');
        return;
    }
    
    if (!especialistaId) {
        alert('No se pudo determinar el especialista. Por favor intente nuevamente.');
        return;
    }
    
    // Crear FormData
    const formData = new URLSearchParams();
    formData.append('especialista_id', especialistaId);
    if (sucursalId) {
        formData.append('sucursal_id', sucursalId);
    }
    formData.append('fecha_inicio', `${fecha} ${horaInicio}:00`);
    formData.append('fecha_fin', `${fecha} ${horaFin}:00`);
    formData.append('tipo', tipo);
    formData.append('motivo', motivo);
    
    try {
        const response = await fetch('<?= BASE_URL ?>/calendario/bloquear', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Horario bloqueado exitosamente');
            closeBlockModal();
            window.calendar.refetchEvents();
        } else {
            alert('Error al bloquear horario: ' + (data.message || 'Error desconocido'));
        }
    } catch (error) {
        console.error('Error al bloquear horario:', error);
        alert('Error al bloquear horario. Por favor intente nuevamente.');
    }
}

// ============= FUNCIONES PARA MODAL DE CIRUGÍA =============

function selectCirugiaAction() {
    // Guardar valores ANTES de cerrar el modal (que los limpia)
    const fecha = selectedDateStr;
    const hora = selectedHoraStr;
    
    closeActionModal();
    
    // Abrir el modal de cirugía con la fecha y hora guardadas
    if (fecha) {
        openSurgeryModal(fecha, hora);
    }
}

function selectConsultaExtraordinariaAction() {
    // Guardar valores ANTES de cerrar el modal (que los limpia)
    const fecha = selectedDateStr;
    const hora = selectedHoraStr;
    
    closeActionModal();
    
    // Abrir el modal de cita extraordinaria con la fecha y hora guardadas
    if (fecha) {
        openCreateModal(fecha, hora, true); // true = es cita extraordinaria
    }
}

function openSurgeryModal(dateStr, horaSeleccionada = null) {
    const modal = document.getElementById('surgeryModal');
    const dateDisplay = document.getElementById('surgery-date-display');
    const dateInput = document.getElementById('surgery_fecha');
    const horaInicioInput = document.getElementById('surgery_hora_inicio');
    const horaFinInput = document.getElementById('surgery_hora_fin');
    
    // Extraer solo la fecha (YYYY-MM-DD) del dateStr
    const fechaSoloDate = dateStr.split('T')[0];
    
    // Formatear fecha para display
    const fecha = new Date(fechaSoloDate + 'T00:00:00');
    const opciones = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const fechaFormateada = fecha.toLocaleDateString('es-MX', opciones);
    
    dateDisplay.textContent = `Cirugía: ${fechaFormateada}`;
    dateInput.value = fechaSoloDate;
    
    // Si viene hora pre-seleccionada, establecerla como inicio y calcular fin (+2 horas para cirugía)
    if (horaSeleccionada) {
        horaInicioInput.value = horaSeleccionada;
        
        // Calcular hora fin (2 horas después para cirugía)
        const [horas, minutos] = horaSeleccionada.split(':');
        const horaFin = new Date();
        horaFin.setHours(parseInt(horas) + 2, parseInt(minutos), 0, 0);
        const horaFinStr = horaFin.toTimeString().substring(0, 5);
        horaFinInput.value = horaFinStr;
    } else {
        // Valores por defecto
        horaInicioInput.value = '09:00';
        horaFinInput.value = '11:00';
    }
    
    // Resetear otros campos
    document.getElementById('surgery_asistentes').value = '';
    
    <?php if (!empty($branches) && count($branches) > 1): ?>
    document.getElementById('surgery_sucursal').value = '';
    <?php endif; ?>
    
    <?php if ($user['rol_id'] == ROLE_SPECIALIST): ?>
    // Si es especialista, determinar automáticamente la sucursal según el día
    const usuarioId = <?= $user['id'] ?>;
    document.getElementById('surgery_especialista_id').value = usuarioId;
    
    // Calcular el día de la semana (1=Lunes, 7=Domingo)
    const dayOfWeek = fecha.getDay();
    const diaSemana = dayOfWeek === 0 ? 7 : dayOfWeek;
    
    // Obtener la sucursal donde trabaja ese día
    fetch(`<?= BASE_URL ?>/api/especialista-sucursal-dia?usuario_id=${usuarioId}&dia_semana=${diaSemana}`)
        .then(response => response.json())
        .then(data => {
            if (data.sucursal_id) {
                document.getElementById('surgery_especialista_id').value = data.especialista_id;
                <?php if (!empty($branches) && count($branches) > 1): ?>
                document.getElementById('surgery_sucursal').value = data.sucursal_id;
                <?php endif; ?>
            } else {
                // No trabaja ese día, preguntar si quiere continuar
                if (!confirm('No tienes horarios configurados para este día. ¿Deseas programar la cirugía de todas formas?')) {
                    closeSurgeryModal();
                    return;
                }
            }
        })
        .catch(error => {
            console.error('Error al obtener sucursal:', error);
        });
    <?php endif; ?>
    
    modal.classList.remove('hidden');
}

function closeSurgeryModal() {
    document.getElementById('surgeryModal').classList.add('hidden');
}

async function submitSurgerySchedule() {
    const especialistaId = document.getElementById('surgery_especialista_id').value;
    const sucursalId = document.getElementById('surgery_sucursal')?.value || null;
    const fecha = document.getElementById('surgery_fecha').value;
    const horaInicio = document.getElementById('surgery_hora_inicio').value;
    const horaFin = document.getElementById('surgery_hora_fin').value;
    const tipo = 'cirugia'; // Tipo fijo para cirugía
    const asistentes = document.getElementById('surgery_asistentes').value;
    
    // Validaciones
    if (!fecha || !horaInicio || !horaFin) {
        alert('Por favor complete todos los campos obligatorios');
        return;
    }
    
    if (horaInicio >= horaFin) {
        alert('La hora de inicio debe ser menor que la hora de fin');
        return;
    }
    
    if (!especialistaId) {
        alert('No se pudo determinar el especialista. Por favor intente nuevamente.');
        return;
    }
    
    // Crear FormData
    const formData = new URLSearchParams();
    formData.append('especialista_id', especialistaId);
    if (sucursalId) {
        formData.append('sucursal_id', sucursalId);
    }
    formData.append('fecha_inicio', `${fecha} ${horaInicio}:00`);
    formData.append('fecha_fin', `${fecha} ${horaFin}:00`);
    formData.append('tipo', tipo);
    formData.append('motivo', asistentes); // Asistentes se guarda en el campo motivo
    
    try {
        const response = await fetch('<?= BASE_URL ?>/calendario/bloquear', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Cirugía programada exitosamente');
            closeSurgeryModal();
            window.calendar.refetchEvents();
        } else {
            alert('Error al programar cirugía: ' + (data.message || 'Error desconocido'));
        }
    } catch (error) {
        console.error('Error al programar cirugía:', error);
        alert('Error al programar cirugía. Por favor intente nuevamente.');
    }
}

// ============= FUNCIONES PARA CREAR RESERVA =============

// Variable global para almacenar la hora pre-seleccionada
let horaPreseleccionada = null;
let createSpecialistRequestId = 0;
let createServicesRequestId = 0;
let createAvailabilityRequestId = 0;

function setCreateSelectionMessage(message = '', type = 'info') {
    const element = document.getElementById('create_selection_message');
    if (!element) return;

    if (!message) {
        element.textContent = '';
        element.className = 'hidden text-sm mt-2';
        return;
    }

    const colors = type === 'error'
        ? 'text-red-700 bg-red-50 border-red-200'
        : type === 'success'
            ? 'text-green-700 bg-green-50 border-green-200'
            : 'text-blue-700 bg-blue-50 border-blue-200';
    element.textContent = message;
    element.className = `text-sm mt-2 px-3 py-2 border rounded-lg ${colors}`;
}

async function readJsonResponse(response) {
    const rawResponse = await response.text();
    let data;
    try {
        data = rawResponse ? JSON.parse(rawResponse) : {};
    } catch (error) {
        throw new Error('El servidor devolvió una respuesta inválida. Recarga la página e intenta nuevamente.');
    }

    if (!response.ok) {
        throw new Error(data.message || data.error || 'No se pudo completar la solicitud.');
    }

    return data;
}

function selectCreateSpecialist(especialistaId) {
    document.getElementById('create_especialista_id').value = especialistaId || '';
    createServicesRequestId++;
    createAvailabilityRequestId++;

    if (especialistaId) {
        setCreateSelectionMessage('Profesionista seleccionado. Ahora elige el servicio.', 'success');
        loadServicesForCreate();
    } else {
        document.getElementById('create_service_section').style.display = 'none';
        document.getElementById('create_time_section').style.display = 'none';
        setCreateSelectionMessage('Selecciona un profesionista para consultar sus servicios.');
    }
}

async function handleCreateBranchChange() {
    const branchSelect = document.getElementById('create_sucursal');
    const branchId = branchSelect?.value || '';
    const specialistInput = document.getElementById('create_especialista_id');

    createSpecialistRequestId++;
    createServicesRequestId++;
    createAvailabilityRequestId++;
    specialistInput.value = '';
    document.getElementById('create_service_section').style.display = 'none';
    document.getElementById('create_time_section').style.display = 'none';

    if (!branchId) {
        setCreateSelectionMessage('Selecciona una sucursal para consultar profesionistas, servicios y horarios.');
        <?php if ($user['rol_id'] != ROLE_SPECIALIST): ?>
        document.getElementById('create_specialist_section').style.display = 'none';
        <?php endif; ?>
        return;
    }

    <?php if ($user['rol_id'] == ROLE_SPECIALIST): ?>
    const specialistId = especialistaPorSucursal[branchId] || '';
    specialistInput.value = specialistId;
    if (!specialistId) {
        setCreateSelectionMessage('Tu perfil no está asociado de forma activa con esta sucursal.', 'error');
        return;
    }
    setCreateSelectionMessage(`Sucursal seleccionada: ${branchSelect.options[branchSelect.selectedIndex].text}.`, 'success');
    await loadServicesForCreate();
    <?php else: ?>
    const requestId = createSpecialistRequestId;
    const specialistSection = document.getElementById('create_specialist_section');
    const specialistSelect = document.getElementById('create_especialista_select');
    specialistSection.style.display = 'block';
    specialistSelect.innerHTML = '<option value="">Cargando profesionistas...</option>';
    specialistSelect.disabled = true;
    setCreateSelectionMessage('Consultando profesionistas de la sucursal...');

    try {
        const response = await fetch(`<?= BASE_URL ?>/api/especialistas?sucursal_id=${encodeURIComponent(branchId)}`);
        const data = await readJsonResponse(response);
        if (requestId !== createSpecialistRequestId || branchSelect.value !== branchId) return;

        const specialists = Array.isArray(data.specialists) ? data.specialists : [];
        specialistSelect.innerHTML = '<option value="">-- Seleccione un profesionista --</option>';
        specialistSelect.disabled = false;

        specialists.forEach(specialist => {
            const option = document.createElement('option');
            option.value = specialist.id;
            option.textContent = `${specialist.nombre} ${specialist.apellidos}`.trim();
            specialistSelect.appendChild(option);
        });

        if (specialists.length === 0) {
            specialistSelect.innerHTML = '<option value="">No hay profesionistas activos en esta sucursal</option>';
            specialistSelect.disabled = true;
            setCreateSelectionMessage('Esta sucursal no tiene profesionistas activos para recibir citas.', 'error');
            return;
        }

        const filteredSpecialist = document.getElementById('filter_especialista')?.value || '';
        const initialSpecialist = specialists.some(item => String(item.id) === String(filteredSpecialist))
            ? filteredSpecialist
            : specialists.length === 1 ? specialists[0].id : '';

        if (initialSpecialist) {
            specialistSelect.value = initialSpecialist;
            selectCreateSpecialist(initialSpecialist);
        } else {
            setCreateSelectionMessage('Selecciona el profesionista que atenderá la cita.');
        }
    } catch (error) {
        if (requestId !== createSpecialistRequestId) return;
        specialistSelect.innerHTML = '<option value="">No se pudieron cargar los profesionistas</option>';
        specialistSelect.disabled = true;
        setCreateSelectionMessage(error.message, 'error');
    }
    <?php endif; ?>
}

function openCreateModal(dateStr, horaSeleccionada = null, esExtraordinaria = false) {
    // Establecer el modo de cita extraordinaria
    esConsultaExtraordinaria = esExtraordinaria;
    
    const modal = document.getElementById('createModal');
    const dateDisplay = document.getElementById('selected-date-display');
    const dateInput = document.getElementById('create_fecha');
    
    // Guardar hora pre-seleccionada para usar después
    horaPreseleccionada = horaSeleccionada;
    console.log('🕐 openCreateModal - Guardando horaPreseleccionada:', horaPreseleccionada);
    console.log('📋 Modo Cita Extraordinaria:', esConsultaExtraordinaria);
    
    // Extraer solo la fecha (YYYY-MM-DD) del dateStr
    // En vista mensual viene "2026-02-15"
    // En vista semanal viene "2026-02-15T14:00:00"
    const fechaSoloDate = dateStr.split('T')[0];
    
    // Formatear fecha para display
    const fecha = new Date(fechaSoloDate + 'T00:00:00');
    const opciones = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const fechaFormateada = fecha.toLocaleDateString('es-MX', opciones);
    
    // Agregar hora al display si fue seleccionada
    let displayText = `Fecha seleccionada: ${fechaFormateada}`;
    if (horaSeleccionada) {
        displayText += ` - Hora: ${horaSeleccionada}`;
    }
    dateDisplay.textContent = displayText;
    dateInput.value = fechaSoloDate;
    
    // Resetear formulario
    document.getElementById('createReservationForm').reset();
    document.getElementById('create_fecha').value = fechaSoloDate;
    document.getElementById('create_service_section').style.display = 'none';
    document.getElementById('create_time_section').style.display = 'none';
    document.getElementById('service_details').classList.add('hidden');
    
    // Ocultar warning de cita extraordinaria
    const extraordinariaWarning = document.getElementById('create_extraordinaria_warning');
    if (extraordinariaWarning) {
        extraordinariaWarning.classList.add('hidden');
    }
    
    // Configurar el checkbox, título y colores según el tipo de cita
    const checkboxExtraordinaria = document.getElementById('create_es_extraordinaria');
    const checkboxContainer = checkboxExtraordinaria?.closest('.flex');
    const checkboxPrimeraConsulta = document.getElementById('create_primera_consulta');
    const primeraConsultaContainer = checkboxPrimeraConsulta?.closest('.p-4');
    const modalTitle = modal.querySelector('h3 span');
    const modalHeader = document.getElementById('createModalHeader');
    const modalSubtitle = document.getElementById('createModalSubtitle');
    const submitBtn = document.getElementById('createModalSubmitBtn');
    
    if (esConsultaExtraordinaria) {
        // CITA EXTRAORDINARIA: Ocultar checkboxes y forzar valores
        if (checkboxContainer) {
            checkboxContainer.style.display = 'none';
        }
        if (checkboxExtraordinaria) {
            checkboxExtraordinaria.checked = true;
        }
        // Mostrar checkbox de primera cita en citas extraordinarias con tema naranja
        if (primeraConsultaContainer) {
            primeraConsultaContainer.style.display = 'block';
            primeraConsultaContainer.className = primeraConsultaContainer.className
                .replace('bg-blue-50', 'bg-orange-50')
                .replace('border-blue-400', 'border-orange-400');
            const icon = primeraConsultaContainer.querySelector('.fa-user-plus');
            if (icon) icon.className = icon.className.replace('text-blue-600', 'text-orange-600');
            const toggle = primeraConsultaContainer.querySelector('.peer-focus\\:ring-blue-300');
            if (toggle) toggle.className = toggle.className
                .replace('peer-focus:ring-blue-300', 'peer-focus:ring-orange-300')
                .replace('peer-checked:bg-blue-600', 'peer-checked:bg-orange-600');
        }
        if (checkboxPrimeraConsulta) {
            checkboxPrimeraConsulta.checked = false;
        }
        if (modalTitle) {
            modalTitle.innerHTML = '<i class="fas fa-user-clock mr-2"></i>Nueva Cita Extraordinaria';
        }
        
        // Cambiar colores a naranja
        if (modalHeader) {
            modalHeader.className = 'p-6 bg-gradient-to-r from-orange-500 to-orange-600 rounded-t-2xl sticky top-0 z-10';
        }
        if (modalSubtitle) {
            modalSubtitle.className = 'text-orange-100 text-sm mt-2';
        }
        if (submitBtn) {
            submitBtn.className = 'px-6 py-2.5 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition shadow-md hover:shadow-lg';
        }
    } else {
        // CITA NORMAL: Mostrar checkboxes y resetear
        if (checkboxContainer) {
            checkboxContainer.style.display = 'flex';
        }
        if (checkboxExtraordinaria) {
            checkboxExtraordinaria.checked = false;
        }
        // Mostrar checkbox de primera cita en citas normales con tema azul
        if (primeraConsultaContainer) {
            primeraConsultaContainer.style.display = 'block';
            primeraConsultaContainer.className = primeraConsultaContainer.className
                .replace('bg-orange-50', 'bg-blue-50')
                .replace('border-orange-400', 'border-blue-400');
            const icon = primeraConsultaContainer.querySelector('.fa-user-plus');
            if (icon) icon.className = icon.className.replace('text-orange-600', 'text-blue-600');
            const toggle = primeraConsultaContainer.querySelector('.peer-focus\\:ring-orange-300');
            if (toggle) toggle.className = toggle.className
                .replace('peer-focus:ring-orange-300', 'peer-focus:ring-blue-300')
                .replace('peer-checked:bg-orange-600', 'peer-checked:bg-blue-600');
        }
        if (checkboxPrimeraConsulta) {
            checkboxPrimeraConsulta.checked = false;
        }
        if (modalTitle) {
            modalTitle.textContent = 'Nueva Reservación';
        }
        
        // Restaurar colores verdes
        if (modalHeader) {
            modalHeader.className = 'p-6 bg-gradient-to-r from-green-500 to-green-600 rounded-t-2xl sticky top-0 z-10';
        }
        if (modalSubtitle) {
            modalSubtitle.className = 'text-green-100 text-sm mt-2';
        }
        if (submitBtn) {
            submitBtn.className = 'px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition shadow-md hover:shadow-lg';
        }
    }
    
    // Mostrar el modal inmediatamente
    modal.classList.remove('hidden');
    
    const sucursalSelect = document.getElementById('create_sucursal');
    const especialistaInput = document.getElementById('create_especialista_id');
    const filtroSucursal = document.getElementById('filter_sucursal')?.value || '';
    const filtroEspecialista = document.getElementById('filter_especialista');
    const diaSemana = fecha.getDay() === 0 ? 7 : fecha.getDay();
    const sucursalesDisponibles = Array.from(sucursalSelect?.options || [])
        .map(option => option.value)
        .filter(Boolean);
    let sucursalInicial = '';

    if (!sucursalSelect || sucursalesDisponibles.length === 0) {
        setCreateSelectionMessage('No hay sucursales activas y autorizadas disponibles para crear la cita.', 'error');
        return;
    }

    if (filtroSucursal && sucursalesDisponibles.includes(String(filtroSucursal))) {
        sucursalInicial = filtroSucursal;
    } else {
        <?php if ($user['rol_id'] == ROLE_SPECIALIST): ?>
        const sucursalesConHorario = sucursalesDisponibles.filter(sucursalId =>
            (horariosPorSucursal[sucursalId] || []).some(horario =>
                parseInt(horario.dia_semana, 10) === diaSemana
            )
        );
        sucursalInicial = sucursalesConHorario[0] || sucursalesDisponibles[0] || '';
        <?php else: ?>
        const sucursalDelFiltro = filtroEspecialista?.selectedOptions?.[0]?.dataset?.branchId || '';
        sucursalInicial = sucursalesDisponibles.includes(String(sucursalDelFiltro))
            ? String(sucursalDelFiltro)
            : sucursalesDisponibles.length === 1 ? sucursalesDisponibles[0] : '';
        <?php endif; ?>
    }

    if (sucursalSelect) sucursalSelect.value = sucursalInicial;
    especialistaInput.value = '';

    if (sucursalInicial) {
        handleCreateBranchChange();
    } else {
        setCreateSelectionMessage('Selecciona una sucursal para consultar los horarios disponibles.');
    }
}

function closeCreateModal() {
    document.getElementById('createModal').classList.add('hidden');
    horaPreseleccionada = null; // Limpiar hora pre-seleccionada
    esConsultaExtraordinaria = false; // Resetear modo extraordinario
    createSpecialistRequestId++;
    createServicesRequestId++;
    createAvailabilityRequestId++;
}

async function loadServicesForCreate() {
    const sucursalId = document.getElementById('create_sucursal')?.value || '';
    const especialistaId = document.getElementById('create_especialista_id').value;
    const serviceSelect = document.getElementById('create_servicio');
    const serviceSection = document.getElementById('create_service_section');
    const requestId = ++createServicesRequestId;
    createAvailabilityRequestId++;

    serviceSelect.innerHTML = '<option value="">Cargando servicios...</option>';
    serviceSelect.disabled = true;
    serviceSection.style.display = 'block';
    document.getElementById('create_hora_inicio').value = '';
    document.getElementById('create_time_section').style.display = 'none';
    document.getElementById('service_details').classList.add('hidden');
    
    if (!sucursalId) {
        document.getElementById('create_especialista_id').value = '';
        serviceSection.style.display = 'none';
        return;
    }
    
    // Cada sucursal tiene un registro de especialista distinto.
    let finalEspecialistaId = especialistaId;
    <?php if ($user['rol_id'] == ROLE_SPECIALIST): ?>
    finalEspecialistaId = especialistaPorSucursal[sucursalId] || '';
    document.getElementById('create_especialista_id').value = finalEspecialistaId;
    <?php endif; ?>
    
    if (!finalEspecialistaId) {
        serviceSection.style.display = 'none';
        setCreateSelectionMessage('Selecciona un profesionista para consultar sus servicios.');
        return;
    }
    
    // La disponibilidad, no la hora pulsada, determina qué espacios puede usar cada servicio.
    try {
        const esExtraordinaria = document.getElementById('create_es_extraordinaria').checked;
        const params = new URLSearchParams({ especialista_id: finalEspecialistaId });
        if (esExtraordinaria) params.set('es_extraordinaria', '1');

        const response = await fetch(`<?= BASE_URL ?>/api/servicios?${params.toString()}`);
        const data = await readJsonResponse(response);
        if (requestId !== createServicesRequestId ||
            document.getElementById('create_sucursal').value !== sucursalId ||
            document.getElementById('create_especialista_id').value !== String(finalEspecialistaId)) {
            return;
        }

        serviceSelect.innerHTML = '<option value="">-- Seleccione un servicio --</option>';
        serviceSelect.disabled = false;
        
        if (data.services && data.services.length > 0) {
            data.services.forEach(service => {
                const option = document.createElement('option');
                option.value = service.id;
                // Agregar emoji de emergencia si es servicio de emergencia
                const emergencyLabel = service.es_emergencia ? '🚨 ' : '';
                option.textContent = `${emergencyLabel}${service.nombre} - ${service.duracion_minutos} min`;
                option.dataset.duracion = service.duracion_minutos;
                option.dataset.precio = service.precio;
                option.dataset.esEmergencia = service.es_emergencia == 1 ? '1' : '0';
                
                // Debug
                console.log(`Servicio: ${service.nombre}, es_emergencia DB: ${service.es_emergencia}, dataset: ${option.dataset.esEmergencia}`);
                
                serviceSelect.appendChild(option);
            });
            setCreateSelectionMessage('Servicios cargados. Selecciona uno para consultar sus horarios.', 'success');
        } else {
            const option = document.createElement('option');
            option.textContent = esExtraordinaria
                ? 'No hay servicios extraordinarios configurados'
                : 'No hay servicios activos para este profesionista';
            option.disabled = true;
            serviceSelect.appendChild(option);
            serviceSelect.disabled = true;
            setCreateSelectionMessage(
                esExtraordinaria
                    ? 'No hay un servicio extraordinario activo para esta sucursal.'
                    : 'El profesionista no tiene servicios activos en esta sucursal.',
                'error'
            );
        }
    } catch (error) {
        if (requestId !== createServicesRequestId) return;
        console.error('Error loading services:', error);
        serviceSelect.innerHTML = '<option value="">No se pudieron cargar los servicios</option>';
        serviceSelect.disabled = true;
        setCreateSelectionMessage(error.message, 'error');
    }
}

async function loadTimeSlotsForCreate() {
    const servicioSelect = document.getElementById('create_servicio');
    const selectedOption = servicioSelect.options[servicioSelect.selectedIndex];
    
    if (!selectedOption.value) return;
    
    console.log('🕐 loadTimeSlotsForCreate - horaPreseleccionada global:', horaPreseleccionada);
    
    // Obtener si es servicio de emergencia
    const esEmergencia = selectedOption.dataset.esEmergencia === '1';
    
    // Obtener si es cita extraordinaria
    const esExtraordinaria = document.getElementById('create_es_extraordinaria').checked;
    
    // Debug: verificar detección
    console.log('Dataset esEmergencia:', selectedOption.dataset.esEmergencia, 'Tipo:', typeof selectedOption.dataset.esEmergencia);
    console.log('Es emergencia (booleano):', esEmergencia);
    console.log('Es extraordinaria:', esExtraordinaria);
    
    // Mostrar detalles del servicio
    document.getElementById('service_duration').textContent = selectedOption.dataset.duracion;
    document.getElementById('service_price').textContent = new Intl.NumberFormat('es-MX', {
        style: 'currency',
        currency: 'MXN'
    }).format(selectedOption.dataset.precio);
    document.getElementById('service_details').classList.remove('hidden');
    
    // Mostrar aviso si es servicio de emergencia
    const emergencyNotice = document.getElementById('emergency_service_notice');
    if (esEmergencia) {
        emergencyNotice.classList.remove('hidden');
    } else {
        emergencyNotice.classList.add('hidden');
    }
    
    // Cargar horarios disponibles
    const especialistaId = document.getElementById('create_especialista_id').value;
    const sucursalId = document.getElementById('create_sucursal').value;
    const servicioId = selectedOption.value;
    const fecha = document.getElementById('create_fecha').value;
    const duracion = parseInt(selectedOption.dataset.duracion);
    
    if (!especialistaId || !sucursalId || !servicioId || !fecha) return;
    const requestId = ++createAvailabilityRequestId;

    document.getElementById('create_hora_inicio').value = '';
    
    // Debug: mostrar parámetros en consola
    console.log('Cargando disponibilidad con:', {
        especialistaId,
        servicioId,
        fecha,
        esServicioEmergencia: esEmergencia,
        esExtraordinaria: esExtraordinaria,
        horaPreseleccionada: horaPreseleccionada
    });
    
    // Mostrar mensaje mientras carga
    const container = document.getElementById('time_slots_container');
    const loadingMsg = horaPreseleccionada 
        ? `<div class="col-span-4 text-center py-2 text-blue-600"><i class="fas fa-spinner fa-spin mr-2"></i>Cargando horarios... (buscando ${horaPreseleccionada})</div>`
        : '<div class="col-span-4 text-center py-2 text-gray-500"><i class="fas fa-spinner fa-spin mr-2"></i>Cargando horarios...</div>';
    container.innerHTML = loadingMsg;
    document.getElementById('create_time_section').style.display = 'block';
    
    // Si es EXTRAORDINARIA, generar todos los horarios posibles
    if (esExtraordinaria) {
        generateAllTimeSlots(container, duracion, horaPreseleccionada);
        return;
    }
    
    // Si NO es extraordinaria, usar API normal
    const availabilityParams = new URLSearchParams({
        especialista_id: especialistaId,
        servicio_id: servicioId,
        fecha: fecha,
        sucursal_id: sucursalId
    });

    try {
            const response = await fetch(`<?= BASE_URL ?>/api/disponibilidad?${availabilityParams.toString()}`);
            const data = await readJsonResponse(response);
            if (requestId !== createAvailabilityRequestId ||
                document.getElementById('create_sucursal').value !== sucursalId ||
                document.getElementById('create_especialista_id').value !== especialistaId ||
                document.getElementById('create_servicio').value !== servicioId) {
                return;
            }

            console.log('===== DEBUG DISPONIBILIDAD =====');
            console.log('Parámetros enviados:', { especialistaId, servicioId, fecha, esEmergencia });
            console.log('Respuesta completa:', data);
            console.log('Cantidad de slots:', data.slots ? data.slots.length : 0);
            if (data.slots && data.slots.length > 0) {
                console.log('Primer slot:', data.slots[0]);
                console.log('Tipos de slots:', data.slots.map(s => s.tipo || 'normal'));
            }
            console.log('================================');
            
            // Mostrar mensaje informativo si es servicio de emergencia
            if (esEmergencia && data.slots && data.slots.length > 0) {
                const hasEmergencySlots = data.slots.some(slot => slot.tipo === 'emergencia');
                if (hasEmergencySlots) {
                    console.log('✅ Mostrando horarios de EMERGENCIA');
                } else {
                    console.warn('⚠️ Servicio de emergencia pero no hay slots de emergencia disponibles');
                }
            }
            
            const container = document.getElementById('time_slots_container');
            const noSlotsMsg = document.getElementById('no_slots_message');
            container.innerHTML = '';
            noSlotsMsg.style.display = 'none';
            
            if (data.slots && data.slots.length > 0) {
                data.slots.forEach(slot => {
                    const button = document.createElement('button');
                    button.type = 'button';
                    
                    // Estilos diferentes para slots de emergencia
                    if (slot.tipo === 'emergencia') {
                        button.className = 'px-3 py-2 border-2 border-red-500 bg-red-50 rounded-lg hover:border-red-700 hover:bg-red-100 transition text-sm font-medium time-slot-btn';
                        button.textContent = '🚨 ' + slot.hora_inicio.substring(0, 5);
                    } else {
                        button.className = 'px-3 py-2 border-2 border-gray-300 rounded-lg hover:border-primary hover:bg-blue-50 transition text-sm font-medium time-slot-btn';
                        button.textContent = slot.hora_inicio.substring(0, 5);
                    }
                    
                    button.dataset.hora = slot.hora_inicio;
                    button.dataset.tipo = slot.tipo || 'normal';
                    button.onclick = function() {
                        // Remover selección previa
                        document.querySelectorAll('.time-slot-btn').forEach(btn => {
                            btn.classList.remove('border-primary', 'bg-blue-100', 'border-red-700', 'bg-red-200');
                        });
                        // Seleccionar este
                        if (this.dataset.tipo === 'emergencia') {
                            this.classList.add('border-red-700', 'bg-red-200');
                        } else {
                            this.classList.add('border-primary', 'bg-blue-100');
                        }
                        document.getElementById('create_hora_inicio').value = this.dataset.hora;
                    };
                    container.appendChild(button);
                    
                    // Auto-seleccionar si coincide con la hora pre-seleccionada
                    if (horaPreseleccionada && slot.hora_inicio.substring(0, 5) === horaPreseleccionada) {
                        // Simular click para seleccionar automáticamente
                        setTimeout(() => {
                            button.click();
                            // Hacer scroll al botón seleccionado y destacarlo
                            button.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                            
                            // Agregar animación de pulso temporal
                            button.style.animation = 'pulse 1s ease-in-out 2';
                            setTimeout(() => {
                                button.style.animation = '';
                            }, 2000);
                        }, 100);
                    }
                });
                noSlotsMsg.style.display = 'none';
                document.getElementById('create_time_section').style.display = 'block';
                
                // Una hora no disponible no debe convertir silenciosamente la cita en extraordinaria.
                if (horaPreseleccionada) {
                    const horaEncontrada = data.slots.some(slot => slot.hora_inicio.substring(0, 5) === horaPreseleccionada);
                    if (!horaEncontrada) {
                        noSlotsMsg.innerHTML = `<i class="fas fa-info-circle mr-1"></i>La hora ${horaPreseleccionada} no está disponible para este servicio. Selecciona uno de los horarios mostrados.`;
                        noSlotsMsg.style.display = 'block';
                    }
                }
            } else {
                noSlotsMsg.innerHTML = `<i class="fas fa-info-circle mr-1"></i>${data.message || 'No hay horarios disponibles para esta fecha y sucursal.'}`;
                noSlotsMsg.style.display = 'block';
                document.getElementById('create_time_section').style.display = 'block';
            }
    } catch (error) {
        if (requestId !== createAvailabilityRequestId) return;
        console.error('Error loading time slots:', error);
        container.innerHTML = `
            <div class="col-span-4 p-3 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg">
                <i class="fas fa-exclamation-triangle mr-1"></i>${error.message}
            </div>
        `;
        const noSlotsMsg = document.getElementById('no_slots_message');
        noSlotsMsg.innerHTML = '<i class="fas fa-info-circle mr-1"></i>No fue posible consultar los horarios. Recarga la página o intenta nuevamente.';
        noSlotsMsg.style.display = 'block';
    }
}

async function submitCreateReservation() {
    const nombreCliente = document.getElementById('create_nombre_cliente')?.value;
    const telefono = document.getElementById('create_telefono')?.value;
    const correo = document.getElementById('create_correo')?.value;
    const sucursalId = document.getElementById('create_sucursal')?.value || '';
    const especialistaId = document.getElementById('create_especialista_id').value;
    const servicioId = document.getElementById('create_servicio').value;
    const fecha = document.getElementById('create_fecha').value;
    const horaInicio = document.getElementById('create_hora_inicio').value;
    const notas = document.getElementById('create_notas').value;
    const esExtraordinaria = document.getElementById('create_es_extraordinaria').checked ? '1' : '0';
    const primeraConsulta = document.getElementById('create_primera_consulta').checked ? '1' : '0';
    
    // Validaciones
    if (!nombreCliente) {
        alert('Por favor ingrese el nombre del cliente');
        return;
    }
    
    // Validar teléfono si se proporciona
    if (telefono && telefono.length !== 10) {
        alert('El teléfono debe tener exactamente 10 dígitos');
        return;
    }
    
    if (!sucursalId || !especialistaId || !servicioId || !fecha || !horaInicio) {
        alert('Por favor complete todos los campos obligatorios');
        return;
    }
    
    // Crear FormData
    const formData = new URLSearchParams();
    formData.append('nombre_cliente', nombreCliente);
    if (telefono) formData.append('telefono', telefono);
    if (correo) formData.append('correo', correo);
    formData.append('sucursal_id', sucursalId);
    formData.append('especialista_id', especialistaId);
    formData.append('servicio_id', servicioId);
    formData.append('fecha_cita', fecha);
    formData.append('hora_inicio', horaInicio);
    formData.append('notas_cliente', notas);
    formData.append('es_extraordinaria', esExtraordinaria);
    formData.append('primera_consulta', primeraConsulta);
    
    const submitButton = document.getElementById('createModalSubmitBtn');
    const originalButtonHtml = submitButton.innerHTML;
    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Validando horario...';

    try {
        const response = await fetch('<?= BASE_URL ?>/reservaciones/nueva', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        });

        const data = await readJsonResponse(response);
        if (data.success) {
            const msgType = esExtraordinaria === '1' ? 'EXTRAORDINARIA ' : '';
            alert(`Reservación ${msgType}creada exitosamente. Código: ${data.codigo}`);
            closeCreateModal();
            horaPreseleccionada = null; // Limpiar hora pre-seleccionada
            window.calendar.refetchEvents();
        }
    } catch (error) {
        console.error('Error al crear reservación:', error);
        alert(error.message || 'Error al crear la reservación. Por favor intente nuevamente.');
    } finally {
        submitButton.disabled = false;
        submitButton.innerHTML = originalButtonHtml;
    }
}

// Toggle warning de cita extraordinaria en modal de calendario
function toggleCreateExtraordinariaWarning(isChecked) {
    esConsultaExtraordinaria = isChecked;
    const warning = document.getElementById('create_extraordinaria_warning');
    if (isChecked) {
        warning.innerHTML = `
            <i class="fas fa-exclamation-triangle mr-2"></i>
            <span><strong>Advertencia:</strong> Esta cita NO validará horarios disponibles y puede causar empalmes.</span>
        `;
        warning.classList.remove('hidden');
    } else {
        warning.classList.add('hidden');
    }
    
    // Los servicios extraordinarios pertenecen a una categoría distinta.
    if (document.getElementById('create_sucursal')?.value) {
        loadServicesForCreate();
    }
}

// Generar todos los horarios posibles (para citas extraordinarias)
async function generateAllTimeSlots(container, duracion, horaPreseleccionada) {
    const noSlotsMsg = document.getElementById('no_slots_message');
    container.innerHTML = '<div class="col-span-4 text-center py-2 text-orange-600"><i class="fas fa-spinner fa-spin mr-2"></i>Generando todos los horarios...</div>';
    noSlotsMsg.style.display = 'none';
    
    console.log('🕐 generateAllTimeSlots llamado con horaPreseleccionada:', horaPreseleccionada);
    
    // SIEMPRE usar rango amplio para citas extraordinarias
    // Sin importar si el especialista tiene horarios configurados
    const horaInicio = 7 * 60;  // 7:00 AM
    const horaFin = 22 * 60;     // 10:00 PM
    
    console.log('🎯 Modo extraordinario: Generando TODOS los slots de 07:00 a 22:00');
    
    container.innerHTML = '';
    
    // Banner informativo
    const infoBanner = document.createElement('div');
    infoBanner.className = 'col-span-4 p-3 bg-orange-100 border border-orange-400 rounded-lg mb-2';
    infoBanner.innerHTML = `
        <div class="flex items-center text-sm text-orange-800">
            <i class="fas fa-info-circle mr-2"></i>
            <span><strong>Creación Manual:</strong> Mostrando TODOS los horarios de 07:00 a 22:00. Puede seleccionar cualquier hora.</span>
        </div>
    `;
    container.appendChild(infoBanner);
    
    const intervalo = 15; // slots cada 15 minutos
    
    console.log(`Generando slots desde ${horaInicio} hasta ${horaFin} minutos (cada ${intervalo} min)`);
    
    let slotsGenerados = 0;
    let horaEncontrada = false;
    
    for (let minutos = horaInicio; minutos < horaFin; minutos += intervalo) {
        const horas = Math.floor(minutos / 60);
        const mins = minutos % 60;
        const horaStr = `${String(horas).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
        const horaCompleta = `${horaStr}:00`;
        
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'px-3 py-2 border-2 border-orange-300 bg-orange-50 rounded-lg hover:border-orange-600 hover:bg-orange-100 transition text-sm font-medium time-slot-btn';
        button.textContent = horaStr;
        button.dataset.hora = horaCompleta;
        button.dataset.tipo = 'extraordinaria';
        
        button.onclick = function() {
            // Remover selección previa
            document.querySelectorAll('.time-slot-btn').forEach(btn => {
                btn.classList.remove('border-orange-600', 'bg-orange-200');
            });
            // Seleccionar este
            this.classList.add('border-orange-600', 'bg-orange-200');
            document.getElementById('create_hora_inicio').value = this.dataset.hora;
            console.log('Hora seleccionada manualmente:', this.dataset.hora);
        };
        
        container.appendChild(button);
        slotsGenerados++;
        
        // Auto-seleccionar si coincide con la hora pre-seleccionada
        if (horaPreseleccionada && horaStr === horaPreseleccionada) {
            console.log(`✅ Hora preseleccionada encontrada: ${horaStr} === ${horaPreseleccionada}`);
            horaEncontrada = true;
            setTimeout(() => {
                button.click();
                button.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                button.style.animation = 'pulse 1s ease-in-out 2';
                setTimeout(() => {
                    button.style.animation = '';
                }, 2000);
            }, 100);
        }
    }
    
    console.log(`✅ Slots generados en modo extraordinario: ${slotsGenerados} (de 07:00 a 22:00)`);
    
    if (horaPreseleccionada && !horaEncontrada) {
        console.warn(`⚠️ La hora preseleccionada ${horaPreseleccionada} NO se encontró en los slots generados`);
    }
    
    if (slotsGenerados === 0) {
        container.innerHTML = '<div class="col-span-4 text-center py-4 text-gray-600"><i class="fas fa-info-circle mr-2"></i>No se pudieron generar horarios</div>';
    }
    
    document.getElementById('create_time_section').style.display = 'block';
}
</script>
